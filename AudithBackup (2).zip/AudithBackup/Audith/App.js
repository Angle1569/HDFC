import React, {useEffect} from 'react';
import AuthProvider from './src/context/AuthContex';
import Navigation from './src/navigations/Navigation';
import SplashScreen from 'react-native-splash-screen';

const App = () => {
  useEffect(() => {
    SplashScreen.hide()
  }, []);

  return (
    <AuthProvider>
      <Navigation />
    </AuthProvider>
  );
};

export default App;
