import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import React from 'react';
import {SvgXml} from 'react-native-svg';
import gland from '../../assets/images/gland';
import {COLORS, SHADOWS} from '../constants/themes';
import AddBtn from '../../assets/images/AddBtn';
import profile from '../../assets/images/profile';

const CustomTab = () => {
  return (
    <View
      style={{
        flexDirection: 'row',
        height: 65,
        bottom: 15,
        marginHorizontal: 16,
        // backfaceVisibility: 'visible',
        backgroundColor: '#FFFFFF',
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 10,
        zIndex: 999,
        // elevation: 0,
        // position: 'absolute',
        borderRadius: 30,
        // borderWidth: 1,
        // ...SHADOWS.light,
      }}>
      <TouchableOpacity
        style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <View style={styles.tabBarContain}>
          <SvgXml xml={gland} height={30} width={30} />
        </View>
      </TouchableOpacity>
      <TouchableOpacity>
        <View style={[styles.tabBarContain, {top: -20, ...SHADOWS.lightRed}]}>
          <SvgXml xml={AddBtn} height={42} width={42} />
        </View>
      </TouchableOpacity>
      <TouchableOpacity>
        <View style={styles.tabBarContain}>
          <SvgXml xml={profile} height={30} width={30} />
        </View>
      </TouchableOpacity>
    </View>
  );
};

export default CustomTab;

const styles = StyleSheet.create({
  imageStyles: {
    width: 25,
    height: 25,
  },
  tabBarContain: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatBotImage: {
    bottom: 20,
    width: 130,
    height: 130,
    // backgroundColor:COLORS
  },
  tabBar: {
    top: -30,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
