import React, {useEffect} from 'react';
import {StyleSheet, Text, TouchableOpacity, View, Image} from 'react-native';
import {COLORS, FONT, SIZES, SHADOWS} from '../constants/themes';
import {SvgXml} from 'react-native-svg';
import AddBtn from '../../assets/images/AddBtn';
import gland from '../../assets/images/gland';
import profile from '../../assets/images/profile';

const TabBar = ({state, descriptors, navigation}) => {
  const focusedOptions = descriptors[state.routes[state.index].key].options;
  if (focusedOptions.tabBarVisible === false) {
    return null;
  }

  useEffect(() => {
    const unsubscribe = navigation.addListener('tabPress', e => {
      e.preventDefault();
    });
    return unsubscribe;
  }, [navigation]);

  return (
    <View
      style={{
        flexDirection: 'row',
        height: 65,
        bottom: 15,
        marginHorizontal: 16,
        // backfaceVisibility: 'visible',
        backgroundColor: '#FFFFFF',
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 10,
        zIndex: 999,
        // elevation: 0,
        // position: 'absolute',
        borderRadius: 30,
        // borderWidth: 1,
        ...SHADOWS.light,
      }}>
      {state.routes.map((route, index) => {
        const {options} = descriptors[route.key];
        const label =
          options.tabBarLabel !== undefined
            ? options.tabBarLabel
            : options.title !== undefined
            ? options.title
            : route.name;

        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name, route.params);
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: 'tabLongPress',
            target: route.key,
          });
        };

        return (
          <TouchableOpacity
            key={index}
            accessibilityRole="button"
            accessibilityState={isFocused ? {selected: true} : {}}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            onLongPress={onLongPress}
            style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
            {label === 'Dashboard' ? (
              <View style={styles.tabBarContain}>
                {isFocused ? (
                  <SvgXml xml={gland} height={30} width={30} />
                ) : (
                  <SvgXml xml={gland} height={30} width={30} />
                )}
                {/* <Text
                  style={{
                    fontFamily: FONT.PoppinsRegular,
                    fontWeight: '500',
                    color: isFocused === true ? COLORS.primary : '#000',
                    fontSize: SIZES.base,
                  }}>
                  {'Home'}
                </Text> */}
              </View>
            ) : label === 'ScheduleNewAuditScreen' ? (
              <View
                style={[styles.tabBarContain, {top: -20, ...SHADOWS.lightRed}]}>
                {isFocused ? (
                  <SvgXml xml={AddBtn} height={42} width={42} />
                ) : (
                  <SvgXml xml={AddBtn} height={42} width={42} />
                )}
                <Text
                  style={{
                    fontFamily: FONT.PoppinsRegular,
                    fontWeight: '500',
                    color: isFocused === true ? COLORS.primary : '#000',
                    fontSize: SIZES.base,
                  }}>
                  {'Schedule Audit'}
                </Text>
              </View>
            ) : label === 'Profile' ? (
              <View style={styles.tabBarContain}>
                {isFocused ? (
                  <SvgXml xml={profile} height={30} width={30} />
                ) : (
                  <SvgXml xml={profile} height={30} width={30} />
                )}
                {/* <Text
                  style={{
                    fontFamily: FONT.PoppinsRegular,
                    fontWeight: '500',
                    color: isFocused === true ? COLORS.primary : '#000',
                    fontSize: SIZES.base,
                  }}>
                  {'Profile'}
                </Text> */}
              </View>
            ) : null}
          </TouchableOpacity>
        );
      })}
    </View>
  );
};

export default TabBar;

const styles = StyleSheet.create({
  imageStyles: {
    width: 25,
    height: 25,
  },
  tabBarContain: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatBotImage: {
    bottom: 20,
    width: 130,
    height: 130,
  },
  tabBar: {
    top: -30,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
