import React, { useContext, useEffect } from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { COLORS } from '../constants/themes';
import AuthNavigation from './AuthNavigation';
import { ActivityIndicator } from 'react-native';
import { AuthContext } from '../context/AuthContex';
import AppNavigation from './AppNavigation';

const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    backgroundColor: 'transparent',
  },
};

const Navigation = () => {
  const { userTokan, isLoading, isUserLogged, userLogin } = useContext(AuthContext);

  console.log("userlogin", userTokan);

  if (isLoading) {
    return (
      <ActivityIndicator
        size="large"
        color={COLORS.primary}
        style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
      />
    );
  }

  return (
    <NavigationContainer theme={theme} independent={true}>
    
      {!userTokan ? <AuthNavigation /> : <AppNavigation />}
    </NavigationContainer>
  );
};

export default Navigation;
