import React from 'react';
import CustomDrawer from './CustomDrawer';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createDrawerNavigator} from '@react-navigation/drawer';
import Login from '../screens/AuthScreens/Login';
import ScheduleNewAuditScreen from '../screens/ScheduleNewAuditScreen';
import Dashbord from '../screens/Dashbord';
import Profile from '../screens/Profile';
import TabBar from './TabBar';
import AuditSuccess from '../screens/AuditSuccess';
import QuestionScreen from '../screens/QuestionScreen';
import AuditList from '../screens/AuditList';
import QuestionScreen2 from '../screens/QuestionScreen2';
import QuestionScreen3 from '../screens/QuestionScreen3';
import QuestionScreen4 from '../screens/QuestionScreen4';

const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();

const TabStack = () => {
  return (
    <Tab.Navigator
    initialRouteName='Dashboard'
      screenOptions={{headerShown: false}}
      // listeners={({navigation, route}) => ({
      //   tabPress: e => {
      //     if (route.state && route.state.routeNames.length > 0) {
      //       navigation.navigate('Device');
      //     }
      //   },
      // })}
      tabBar={props => <TabBar {...props} />}>
      <Tab.Screen name="Dashboard" component={Dashbord} />
      <Tab.Screen
        name="ScheduleNewAuditScreen"
        component={ScheduleNewAuditScreen}
      />
      <Tab.Screen name="Profile" component={Profile} />
    </Tab.Navigator>
  );
};

const AppNavigation = () => {
  return (
    <Drawer.Navigator
      initialRouteName="DashboardScreen"
      drawerContent={props => <CustomDrawer {...props} />}
      screenOptions={{
        headerShown: false,
      }}>
      <Drawer.Screen name="DashboardScreen" component={TabStack} />
      {/* <Drawer.Screen
        name="ScheduleNewAuditScreen"
        component={ScheduleNewAuditScreen}
      /> */}
      <Drawer.Screen name="AudithList" component={AuditList} />
      <Drawer.Screen name="QuestionScreen" component={QuestionScreen} />
      <Drawer.Screen name="AuditSuccess" component={AuditSuccess} />
      <Drawer.Screen name='Question2' component={QuestionScreen2}/>
      <Drawer.Screen name='Question3' component={QuestionScreen3}/>
      <Drawer.Screen name='Question4' component={QuestionScreen4}/>
    </Drawer.Navigator>
  );
};

export default AppNavigation;
