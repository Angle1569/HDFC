import React,{useContext} from 'react';
import {StyleSheet, Text, View, Image, TouchableOpacity} from 'react-native';
import {DrawerContentScrollView, DrawerItem} from '@react-navigation/drawer';
import {
  Auditor,
  COLORS,
  DASHBOARD,
  FONT,
  LOGOUT_ICON,
  Logo,
  SIZES,
} from '../constants/themes';
import { AuthContext } from '../context/AuthContex';

const CustomDrawer = ({props, navigation}) => {
  const { userLogout } = useContext(AuthContext)

  return (
    <View style={{flex: 1, backgroundColor: COLORS.white}}>
      <DrawerContentScrollView>
        <View style={{flexGrow: 1, paddingHorizontal: 20}}>
          <Image source={Logo} style={styles.img} />
          <View
            style={{
              backgroundColor: COLORS.grayTextColor,
              height: 1,
              marginTop: 10,
              // borderWidth: 1,
            }}></View>

          <View style={styles.contain}>
            <TouchableOpacity
              style={styles.touch}
              onPress={() => navigation.navigate('DashboardScreen')}>
              {/* <Image
                source={DASHBOARD}
                style={{marginHorizontal: 10, marginVertical: 10,}}
              /> */}
              <Text style={styles.text}>Dashboard</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.contain}>
            <TouchableOpacity style={styles.touch} onPress={userLogout}>
              {/* <Image
                source={LOGOUT_ICON}
                style={{marginHorizontal: 10, marginVertical: 10}}
              /> */}
              <Text style={styles.text}>Logout</Text>
            </TouchableOpacity>
          </View>
        </View>
      </DrawerContentScrollView>
    </View>
  );
};

export default CustomDrawer;

const styles = StyleSheet.create({
  contain: {
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 10,
    // borderWidth: 1,
  },
  img: {
    width: 150,
    height: 80,
    alignSelf: 'center',
    resizeMode: 'contain',
  },
  touch: {
    flexDirection: 'row',
    // alignItems: 'center',
    paddingVertical: 10,
    // borderWidth:1,
    // justifyContent: 'center',
  },
  text: {
    color: COLORS.primary,
    fontFamily: FONT.PoppinsRegular,
    fontSize: SIZES.medium,
    marginHorizontal: 20, 
    // borderWidth: 1
  },
});
