import {View, Text, ScrollView, Image, ActivityIndicator} from 'react-native';
import React, {useState, useEffect} from 'react';
import Header from '../components/Header';
import {Input} from '../components/CustomInput';
import {PrimaryBtn} from '../components/CustomButtom';
import {styles} from '../../assets/css/MainStyles';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Profile = ({navigation}) => {
  const [firstName, setfirstName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [showBtnImage, setShowBtnImage] = useState(false);
  const [password, setPassword] = useState('');
  const [userData, setUserData] = useState([]);
  const [isLoading, setLoading] = useState(false);
  const [isAdminId, setAdminId] = useState('');

  useEffect(() => {
    profileData();
  }, [isAdminId]);

  const profileData = async () => {
    setLoading(true);
    try {
      const userLognDetails = await AsyncStorage.getItem('userDetauls');
      const transformedLoginData = JSON.parse(userLognDetails);
      const adminId = transformedLoginData.userDetauls.fldi_admin_id;

      setAdminId(adminId);
      var myHeaders = new Headers();
      myHeaders.append('Authorization', 'Basic YXBpdXNlcjp3ZWIk');
      myHeaders.append(
        'Cookie',
        'sab=770a34e74cdbb889cc90e7c5e9786399cbda953e',
      );

      var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow',
      };

      const response = await fetch(
        `https://demo.crayoninfotech.com/adityabirla/api/auth/get_userInfo?id=${isAdminId}`,
        requestOptions,
      );
      const resJson = await response.json();
      setLoading(false);
      console.log('reponse', resJson)
      setUserData(resJson.result);
      setEmail(resJson.result.fldv_email);
      setfirstName(resJson.result.fldv_name);
      setMobile(resJson.result.fldv_mobile);
    } catch (error) {
      console.log(error.message);
    }
  };

  console.log(isAdminId)
  
  if (isLoading) {
    <ActivityIndicator
      size="large"
      color="#AB1E24"
      style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}
    />;
  }

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={{flexGrow: 1}}>
        <Header onPress={() => navigation.openDrawer()} />
        <View style={{marginHorizontal: 20, marginVertical: 20, flex: 4}}>
          <Input
            label={'First Name'}
            placeholder={'First Name'}
            containerStyle={styles.display}
            value={firstName}
            setValue={setfirstName}
            secureTextEntry={false}
          />
          <Input
            label={'Email'}
            placeholder={'Email'}
            containerStyle={styles.display}
            value={email}
            setValue={setEmail}
            secureTextEntry={false}
          />
          <Input
            label={'Contact Number'}
            placeholder={'Contact Number'}
            containerStyle={styles.display}
            value={mobile}
            setValue={setMobile}
            keyboardType={'number-pad'}
            secureTextEntry={false}
          />
          <Input
            label={'Password'}
            placeholder={'Password'}
            containerStyle={styles.display}
            value={password}
            setValue={setPassword}
            keyboardType={'number-pad'}
            secureTextEntry={true}
          />
          {showBtnImage && (
            <Image
              style={{width: 25, height: 25, right: 10}}
              source={btnLeftImage}
            />
          )}
          <View style={{paddingTop: 30}}>
            <PrimaryBtn onPress={() => {}} btnText={'Update'} />
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default Profile;
