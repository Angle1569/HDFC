import {View, Text} from 'react-native';
import React from 'react';

const Notification = () => {
  return (
    <View>
      <Text>Notification</Text>
    </View>
  );
};

export default Notification;
