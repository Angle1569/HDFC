import React, {useEffect, useState, useCallback} from 'react';
import {View, Text, ScrollView, TouchableOpacity} from 'react-native';
import {BackHeader} from '../components/Header';
import {COLORS, FONT, SIZES} from '../constants/themes';
import DatePicker from 'react-native-date-picker';
import moment from 'moment';
import {PrimaryBtn} from '../components/CustomButtom';
import {styles} from '../../assets/css/MainStyles';
import Calendar from '../../assets/images/Calendar';
import {SvgXml} from 'react-native-svg';
import Clock from '../../assets/images/Clock';
import {GET_BASE_URL, Token} from '../constants/api';
import {Dropdown} from 'react-native-element-dropdown';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useIsFocused} from '@react-navigation/native';

const ScheduleNewAuditScreen = ({navigation}) => {
  const [isLoading, setLoading] = useState(false);
  const [openDate, setopenDate] = useState(false);
  const [Cdate, setCdate] = useState(new Date());
  const [openTime, setopenTime] = useState(false);
  const [getStateName, setGetStateName] = useState([]);
  const [citysName, setCitysName] = useState([]);
  const [time, settime] = useState('');
  const [date, setdate] = useState('');
  const [branchNameId, setbranchNameId] = useState();
  const [adminId, setAdminId] = useState();
  const [value, setValue] = useState(null);
  const [valueState, setValueState] = useState(null);
  const [isFocus, setIsFocus] = useState(false);
  const isFocused = useIsFocused();

  useEffect(() => {
    setValue(null);
    setValueState(null);
    settime('');
    setdate('');
    fetchDataAsync();
    data();
  }, [isFocused, data]);

  const fetchDataAsync = async () => {
    setLoading(true);
    const userLognDetails = await AsyncStorage.getItem('userDetauls');
    if (!userLognDetails) {
      // Alert.alert("Unable to fetch mobile number, Login again");
      return;
    }
    const transformedLoginData = JSON.parse(userLognDetails);

    const adminId = transformedLoginData.userDetauls.fldi_admin_id;
    // console.log('transformedStoreData adminId --->', adminId);
    // const userName = transformedLoginData.userDetauls.fldv_name;

    setAdminId(adminId);
    // setname(userName);
  };

  const data = useCallback(async () => {
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', Token);

      var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow',
      };

      const response = await fetch(
        GET_BASE_URL + 'citylist_for_brach_detail',
        requestOptions,
      );

      const resJSON = await response.json();
      setLoading(false);
      setCitysName(resJSON.result);
      // setbranchNameId(resJSON.result[0].fldi_id)
      // const cityNames = cityList.map(cityObject => cityObject.fldv_city);
      // console.log('setCitysName====>', citysName);
      // setCitysName(cityNames);
    } catch (error) {
      console.log(error);
    }
  }, []);

  useEffect(() => {
    if (value !== null) {
      getCityData();
    }
  }, [value, getCityData]);

  const getCityData = useCallback(async () => {
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', Token);

      var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow',
      };

      const response = await fetch(
        GET_BASE_URL + `branchlist?city=${value}`,
        requestOptions,
      );
      const resJSON = await response.json();
      setLoading(false);
      console.log('respose get City Data==>', resJSON.result);
      setGetStateName(resJSON.result);
      setbranchNameId(resJSON.result[0].fldi_id);
    } catch (error) {
      console.log(error);
    }
  }, [value]);

  const handleSumbit = async () => {
    if (!valueState || !time || !date || !value) {
      setLoading(false);
      alert('Please fill the details');
      return;
    }
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', 'Basic YXBpdXNlcjp3ZWIk');
      myHeaders.append(
        'Cookie',
        'sab=ec91f64ebcef7696d11d711d804c3696503e6e82',
      );

      var formdata = new FormData();
      formdata.append('branch_id', branchNameId);
      formdata.append('admin_id', adminId);
      formdata.append('audit_date', date);
      formdata.append('audit_time', time);

      var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow',
      };

      const response = await fetch(
        'https://demo.crayoninfotech.com/adityabirla/api/auth/create_audit',
        requestOptions,
      );
      const resJson = await response.json();
      setLoading(false);
      console.log(resJson);

      if (resJson.status === 'success') {
        alert(resJson.message);
        setTimeout(() => {
          navigation.navigate('Dashboard');
        }, 1500);
      } else {
        alert(resJson.message);
      }
      // console.log(resJson)
    } catch (error) {
      console.log(error.message);
    }
    // navigation.navigate('DashboardScreen');
  };

  return (
    <>
      <ScrollView
        contentContainerStyle={{flexGrow: 1}}
        keyboardShouldPersistTaps="always">
        <View style={{flex: 1, backgroundColor: COLORS.background}}>
          <BackHeader
            onPress={() => {
              navigation.goBack();
            }}
          />
          <View
            style={{
              paddingHorizontal: 20,
              paddingVertical: 35,
            }}>
            <Text style={styles.nameHeader}>Schedule a Audit</Text>
            <Text style={styles.text}>
              Select a branch name as well as date and time
            </Text>
          </View>
          <View
            style={{
              top: 30,
              paddingHorizontal: 20,
              backgroundColor: COLORS.white,
              borderTopLeftRadius: 24,
              borderTopRightRadius: 24,
              // justifyContent: 'space-evenly',
            }}>
            <View
              style={{
                backgroundColor: COLORS.white,
                paddingVertical: 24,
              }}>
              <Text style={styles.txt_head}>Branch City *</Text>
              <Dropdown
                style={{
                  backgroundColor: COLORS.grayTextColor,
                  marginVertical: 10,
                  height: 50,
                  borderRadius: 8,
                  paddingHorizontal: 15,
                  paddingVertical: 10,
                }}
                placeholderStyle={{
                  color: COLORS.textBlack,
                  fontSize: SIZES.small,
                  fontFamily: FONT.PoppinsRegular,
                }}
                selectedTextStyle={{
                  color: COLORS.textBlack,
                  fontSize: SIZES.small,
                }}
                itemTextStyle={{
                  color: COLORS.textBlack,
                  fontSize: SIZES.small,
                  fontFamily: FONT.PoppinsRegular,
                }}
                iconStyle={{width: 20, height: 20}}
                data={citysName.map((item, index) => ({
                  label: item.fldv_city,
                  value: item.fldv_city,
                }))}
                // search
                maxHeight={300}
                labelField="label"
                valueField="value"
                placeholder={!isFocus ? 'Select item' : '...'}
                // searchPlaceholder="Search..."
                value={value}
                onFocus={() => setIsFocus(true)}
                onBlur={() => setIsFocus(false)}
                onChange={item => {
                  // console.log('item', item);
                  setValue(item.label);
                  setIsFocus(false);
                  // console.log(value)
                }}
              />
              <Text style={styles.txt_head}>Branch Name *</Text>
              <Dropdown
                style={{
                  backgroundColor: COLORS.grayTextColor,
                  marginVertical: 10,
                  height: 50,
                  borderRadius: 8,
                  paddingHorizontal: 15,
                  paddingVertical: 10,
                }}
                placeholderStyle={{
                  color: COLORS.textBlack,
                  fontSize: SIZES.small,
                  fontFamily: FONT.PoppinsRegular,
                }}
                selectedTextStyle={{
                  color: COLORS.textBlack,
                  fontSize: SIZES.small,
                }}
                itemTextStyle={{
                  color: COLORS.textBlack,
                  fontSize: SIZES.small,
                  fontFamily: FONT.PoppinsRegular,
                }}
                iconStyle={{width: 20, height: 20}}
                // data={datalist}
                data={getStateName.map((item, index) => ({
                  label: item.fldv_state,
                  value: item.fldv_state,
                }))}
                // search
                maxHeight={300}
                labelField="label"
                valueField="value"
                placeholder={!isFocus ? 'Select item' : '...'}
                // searchPlaceholder="Search..."
                value={valueState}
                onFocus={() => setIsFocus(true)}
                onBlur={() => setIsFocus(false)}
                onChange={item => {
                  console.log('item', item);
                  setValueState(item.label);
                  setIsFocus(false);
                  console.log(valueState);
                }}
              />
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginVertical: 10,
                  // borderWidth: 1
                }}>
                <View style={{width: '45%'}}>
                  <Text style={styles.txt_head}>Date *</Text>
                  {/* Date Picker */}
                  <TouchableOpacity
                    style={styles.date_time}
                    onPress={() => {
                      setopenDate(true);
                    }}>
                    {date ? (
                      <Text style={{color: 'black'}}>{date}</Text>
                    ) : (
                      <Text style={{color: COLORS.textGray}}>00-00-0000</Text>
                    )}
                    <SvgXml
                      xml={Calendar}
                      height={24}
                      width={24}
                      style={{left: 30}}
                    />
                  </TouchableOpacity>
                  <DatePicker
                    modal
                    open={openDate}
                    mode="date"
                    date={Cdate}
                    onConfirm={date => {
                      setopenDate(false);
                      // setdate(date)
                      if (
                        moment(date).format('DD-MM-YYYY') <
                        moment(moment()).format('DD-MM-YYYY')
                      ) {
                        alert('You cant select previous date');
                      } else {
                        // if (
                        //   moment(date).format('DD-MM-YYYY') ==
                        //   moment(moment()).format('DD-MM-YYYY')
                        // ) {
                        //   if (time < moment(new Date()).format('H-mm')) {
                        //     alert('Please select vaild time.');
                        //     settime();
                        //   } else {
                        //     setopenDate(false);
                        //     setdate(moment(date).format('DD-MM-YYYY'));
                        //   }
                        // } else {
                        setopenDate(false);
                        // ACDATE = moment(date).format('DD-MM-YYYY');
                        setdate(moment(date).format('DD-MM-YYYY'));
                      }
                      // }
                    }}
                    onCancel={() => {
                      setopenDate(false);
                    }}
                  />
                </View>

                <View style={{width: '45%', marginLeft: 5}}>
                  <Text style={styles.txt_head}>Time *</Text>
                  <TouchableOpacity
                    onPress={() => setopenTime(true)}
                    style={{
                      backgroundColor: COLORS.grayTextColor,
                      flexDirection: 'row',
                      alignItems: 'center',
                      borderRadius: 8,
                      justifyContent: 'space-between',
                      paddingVertical: 10,
                      paddingHorizontal: 10,
                    }}>
                    {/* <Image source={CLOCK} /> */}
                    <Text style={{color: COLORS.black}}>
                      {time ? time : 'Time'}
                    </Text>
                    <SvgXml
                      xml={Clock}
                      height={24}
                      width={24}
                      style={{marginLeft: 10}}
                    />
                  </TouchableOpacity>
                  <DatePicker
                    modal
                    open={openTime}
                    mode="time"
                    date={Cdate}
                    onConfirm={time => {
                      setopenTime(false);
                      if (time < moment(new Date()).format('H:mm')) {
                        alert('Please select vaild time.');
                        settime();
                      } else {
                        setopenTime(false);
                        // ACDATE = moment(time).format('H:mm');
                        settime(moment(time).format('H:mm'));
                      }
                    }}
                    onCancel={() => {
                      setopenTime(false);
                    }}
                  />
                </View>
              </View>

              {/* Time Set  */}
            </View>
            <View style={{marginVertical: 35}}>
              <PrimaryBtn btnText={'Schedule'} onPress={handleSumbit} />
            </View>
          </View>
        </View>
      </ScrollView>
    </>
  );
};

export default ScheduleNewAuditScreen;
