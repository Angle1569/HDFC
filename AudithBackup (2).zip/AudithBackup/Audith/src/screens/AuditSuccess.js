import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Image,
  ScrollView,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import {styles} from '../../assets/css/MainStyles';
import {PrimaryBtn} from '../components/CustomButtom';
import {SvgXml} from 'react-native-svg';
import {COLORS, Logo, FONT, SIZES} from '../constants/themes';
import Bell from '../../assets/images/Bell';
import TabBar from '../navigations/TabBar';
import CustomTab from '../navigations/CustomTab';
import Header from '../components/Header';

const WindowWidth = Dimensions.get('window').width;
const WindowHeight = Dimensions.get('window').height;

const AuditSuccess = ({navigation}) => {
  const [isLoading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [image, setImage] = useState('');

  useEffect(() => {
    handleHome();
  }, [handleHome]);

  const handleHome = async () => {
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', 'Basic YXBpdXNlcjp3ZWIk');

      var formdata = new FormData();
      formdata.append('audit_id', '1');

      var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow',
      };
      const response = await fetch(
        'https://demo.crayoninfotech.com/adityabirla/api/auth/audit_deatils',
        requestOptions,
      );
      const resJson = await response.json();
      setLoading(false);

      console.log('ThanYou Page', resJson.result);
      setData(resJson.result);
      // setImage(re)
    } catch (error) {
      console.log(error);
    }

    // navigation.navigate('DashboardScreen');
  };

  return (
    <View style={{flex: 1, backgroundColor: COLORS.background}}>
      <View
        style={{
          alignItems: 'center',
          flexDirection: 'row',
          justifyContent: 'space-between',
          height: Platform.OS == 'ios' ? 90 : 60,
          paddingTop: Platform.OS == 'ios' ? 30 : 0,
          marginHorizontal: 16,
        }}>
        <TouchableOpacity onPress={() => navigation.openDrawer()}>
          <Image
            source={Logo}
            style={{
              width: 90,
              height: 50,
              resizeMode: 'contain',
              alignSelf: 'center',
            }}
          />
        </TouchableOpacity>
        <SvgXml xml={Bell} width={34} height={34} />
      </View>
      {/* <Header onPress={() => navigation.openDrawer()} /> */}
      <ScrollView contentContainerStyle={{flexGrow: 1}}>
        <View
          style={{
            paddingHorizontal: 20,
            paddingVertical: 45,
          }}>
          <Text style={styles.nameHeader}>
            Thank You for Completing Your Audit!
          </Text>
          <Text style={styles.text}>
            Your audit has been successfully submitted
          </Text>
        </View>
        <View
          style={{
            top: 30,
            paddingHorizontal: 20,
            backgroundColor: COLORS.white,
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
            // justifyContent: 'space-evenly',
          }}>
          <View
            style={{
              backgroundColor: COLORS.white,
              paddingVertical: 24,
            }}>
            <Text
              style={{
                fontFamily: FONT.PoppinsRegular,
                color: COLORS.textBlack,
                fontSize: SIZES.medium,
                fontWeight: '400',
                lineHeight: 18,
              }}>
              Uploaded Images
            </Text>
            <View
              style={{
                width: '100%',
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginVertical: 16,
                // borderWidth:1
              }}>
              <View>
                {/* {data.map(item => {
                  return (
                    <View>
                      <Image
                        // source={require('../../assets/images/Frame.png')}
                        source={{uri: item.fldv_image}}
                        style={{height: 80, width: 80}}
                      />
                    </View>
                  );
                })} */}
                <Image
                  source={require('../../assets/images/Frame.png')}
                  // source={{uri: data.fldv_image }}
                  style={{height: 80, width: 80}}
                />
                <Text style={{color: COLORS.black, alignSelf: 'center'}}>
                  Image 1
                </Text>
              </View>
              <View>
                <Image
                  source={require('../../assets/images/Frame.png')}
                  style={{height: 80, width: 80}}
                />
                <Text style={{color: COLORS.black, alignSelf: 'center'}}>
                  Image 2
                </Text>
              </View>
              <View>
                <Image
                  source={require('../../assets/images/Frame.png')}
                  style={{height: 80, width: 80}}
                />
                <Text style={{color: COLORS.black, alignSelf: 'center'}}>
                  Image 3
                </Text>
              </View>
              <View>
                <Image
                  source={require('../../assets/images/Frame.png')}
                  style={{height: 80, width: 80}}
                />
                <Text style={{color: COLORS.black, alignSelf: 'center'}}>
                  Image 4
                </Text>
              </View>
            </View>
            <View style={{marginVertical: 40}}>
              <PrimaryBtn
                btnText={'Go back to the Dashboard'}
                onPress={() => navigation.navigate('DashboardScreen')}
              />
            </View>
          </View>
        </View>
      </ScrollView>
      {/* <View style={{position: "relative", flex: 1}}>
     <CustomTab />
      </View> */}
    </View>
  );
};

export default AuditSuccess;
