import React, {useEffect, useState, useCallback} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  ScrollView,
  StatusBar,
  TouchableOpacity,
  Image,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import Header from '../components/Header';
import {ADD_ICON, COLORS, Dashbord_Heroic, SHADOWS} from '../constants/themes';
import AvterYello from '../../assets/images/AvterYello';
import {SvgXml} from 'react-native-svg';
import {styles} from '../../assets/css/MainStyles';
import VectorBlue from '../../assets/images/VectorBlue';
import VectorRed from '../../assets/images/VectorRed';
import VectorOrange from '../../assets/images/VectorOrange';
import VectorGreen from '../../assets/images/VectorGreen';
import AuditStart from '../../assets/images/AuditStart';
import LinearGradient from 'react-native-linear-gradient';
import {AUTH_BASE_URL, GET_BASE_URL, Token} from '../constants/api';
import {dashbordCountList, dashbordList} from '../constants/AllApiCall';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useIsFocused} from '@react-navigation/native';

const Dashbord = ({navigation}) => {
  const [isLoading, setLoading] = useState(false);
  const [name, setname] = useState('');
  const [refreshing, setRefreshing] = useState(false);
  const [upcomingCount, setUpcomingCount] = useState('');
  const [totalCount, setTotalCount] = useState('');
  const [completCount, setCompletCount] = useState('');
  const [inProgessCount, setInProgessCount] = useState('');
  const [cancelledCount, setCancelledCount] = useState('');
  const [isAdminId, setAdminId] = useState('');
  const [isStatusIdCom, setStatusIdCom] = useState('');
  const [isStatusIdIn, setStatusIdIn] = useState('');
  const [isStatusIdCan, setStatusIdCan] = useState('');
  const [isStatusIdUp, setStatusIdUp] = useState('');
  const isFocused = useIsFocused();

  //   const onRefresh = useCallback(() => {
  //     setRefreshing(true);
  //     wait(1000).then(() => setRefreshing(false));
  // }, []);

  useEffect(() => {
    fetchDataAsync();
    DashbordCount();
    DashbordStartId();
  }, [isFocused]);

  const fetchDataAsync = async () => {
    setLoading(true);
    const userLognDetails = await AsyncStorage.getItem('userDetauls');
    if (!userLognDetails) {
      // Alert.alert("Unable to fetch mobile number, Login again");
      return;
    }
    const transformedLoginData = JSON.parse(userLognDetails);

    // console.log('transformedStoreData --->', transformedLoginData);

    const adminId = transformedLoginData.userDetauls.fldi_admin_id;
    const userName = transformedLoginData.userDetauls.fldv_name;

    setAdminId(adminId);
    setname(userName);
  };

  // console.log(name,isAdminId )

  const DashbordCount = async () => {
    try {
      setLoading(true);
      const response = await dashbordCountList();
      setLoading(false);
      // console.log("dashbord", response);
      setUpcomingCount(response.Upcoming);
      setCancelledCount(response.Cancelled);
      setTotalCount(response.Total);
      setInProgessCount(response.Inprogress);
      setCompletCount(response.Completed);
    } catch (error) {
      console.log(error.message);
    }
  };

  const DashbordStartId = async () => {
    try {
      setLoading(true);
      const response = await dashbordList();
      setLoading(false);
      setStatusIdCom(response.result[0].fldi_status_id);
      setStatusIdIn(response.result[1].fldi_status_id);
      setStatusIdCan(response.result[2].fldi_status_id);
      setStatusIdUp(response.result[3].fldi_status_id);
      // console.log(result);
    } catch (error) {
      console.log(error.message);
    }
  };

  // if (isLoading) {
  //   return (
  //     <ActivityIndicator
  //       size="large"
  //       color="#ce211c"
  //       style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
  //     />
  //   );
  // }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.white} />
      <Header onPress={() => navigation.openDrawer()} />
      <ScrollView
        showsHorizontalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={isLoading}
            progressBackgroundColor={COLORS.primary}
            colors={[COLORS.white]}
            tintColor={COLORS.white}
          />
        }>
        <View style={{flexGrow: 1, paddingBottom: 30}}>
          <View
            style={{
              marginHorizontal: 16,
              marginVertical: 14,
            }}>
            <Text style={styles.nameHeader}>{name}</Text>
            <Text style={styles.text}>Audit Overview</Text>
          </View>

          <View
            style={{
              flexDirection: 'row',
              flexWrap: 'wrap',
              justifyContent: 'space-between',
              marginHorizontal: 16,
              // borderWidth:1
            }}>
            <TouchableOpacity
              activeOpacity={0.75}
              style={{
                width: '48%',
                marginBottom: 15,
                backgroundColor: COLORS.white,
                // height: 170,
                alignItems: 'center',
                ...SHADOWS.light,
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                borderBottomLeftRadius: 8,
                borderBottomRightRadius: 8,
                // borderWidth: 1,
              }}
              onPress={() => navigation.navigate('QuestionScreen')}>
              <SvgXml
                xml={AuditStart}
                height={120}
                width={50}
                style={{alignSelf: 'center'}}
              />
              {/* <SvgXml xml={Bottom} height={70} width={'100%'} /> */}
              <LinearGradient
                colors={['#AB1E24', '#F07033', '#F07033']}
                style={{
                  // borderRadius: 8,
                  width: '100%',
                  ...SHADOWS.light,
                  borderBottomLeftRadius: 8,
                  borderBottomRightRadius: 8,
                  height: 70,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                start={{x: 0, y: 0}}
                end={{x: 1, y: 0}}>
                <Text style={[styles.p_text, {color: COLORS.white}]}>
                  Start Audit
                </Text>
                {/* <Text style={styles.txtgray}>101</Text> */}
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.85}
              style={{
                width: '48%',
                marginBottom: 15,
                alignItems: 'center',
                ...SHADOWS.light,
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                backgroundColor: '#FFF7E4',
                borderBottomLeftRadius: 8,
                borderBottomRightRadius: 8,
              }}
              onPress={() =>
                navigation.navigate('AudithList', {
                  params: {status_id: '0'},
                })
              }>
              <SvgXml
                xml={AvterYello}
                height={120}
                width={150}
                style={{alignSelf: 'center'}}
              />
              <View
                style={{
                  borderBottomLeftRadius: 8,
                  borderBottomRightRadius: 8,
                  backgroundColor: COLORS.yellow,
                  width: '100%',
                  height: 70,
                  alignItems: 'center',
                  justifyContent: 'center',
                  ...SHADOWS.light,
                  borderBottomLeftRadius: 8,
                  borderBottomRightRadius: 8,
                }}>
                <Text style={styles.p_text}>Total Audit</Text>
                <Text style={styles.txtgray}>
                  {totalCount ? totalCount : 0}
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.85}
              onPress={() =>
                navigation.navigate('AudithList', {
                  params: {status_id: isStatusIdCom},
                })
              }
              style={{
                width: '48%',
                marginBottom: 15,
                alignItems: 'center',
                ...SHADOWS.light,
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                backgroundColor: COLORS.lightGreen,
                borderBottomLeftRadius: 8,
                borderBottomRightRadius: 8,
              }}>
              <SvgXml
                xml={VectorGreen}
                height={120}
                width={100}
                style={{alignSelf: 'center'}}
              />
              <View
                style={{
                  borderBottomLeftRadius: 8,
                  borderBottomRightRadius: 8,
                  backgroundColor: COLORS.green,
                  width: '100%',
                  height: 70,
                  alignItems: 'center',
                  justifyContent: 'center',
                  ...SHADOWS.light,
                }}>
                <Text style={styles.p_text}>Completed</Text>
                <Text style={styles.txtgray}>
                  {completCount ? completCount : 0}
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.85}
              onPress={() =>
                navigation.navigate('AudithList', {
                  params: {status_id: isStatusIdIn},
                })
              }
              style={{
                backgroundColor: COLORS.lightBlue,
                width: '48%',
                marginBottom: 15,
                alignItems: 'center',
                ...SHADOWS.light,
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                borderBottomLeftRadius: 8,
                borderBottomRightRadius: 8,
              }}>
              <SvgXml
                xml={VectorBlue}
                height={120}
                width={90}
                style={{alignSelf: 'center'}}
              />
              <View
                style={{
                  backgroundColor: COLORS.blue,
                  borderBottomLeftRadius: 8,
                  borderBottomRightRadius: 8,
                  width: '100%',
                  height: 70,
                  alignItems: 'center',
                  justifyContent: 'center',
                  ...SHADOWS.light,
                }}>
                <Text style={styles.p_text}>In Progress</Text>
                <Text style={styles.txtgray}>
                  {inProgessCount ? inProgessCount : 0}
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.85}
              onPress={() =>
                navigation.navigate('AudithList', {
                  params: {status_id: isStatusIdCan},
                })
              }
              style={{
                backgroundColor: COLORS.lightRed,
                width: '48%',
                marginBottom: 15,
                alignItems: 'center',
                ...SHADOWS.light,
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                borderBottomLeftRadius: 8,
                borderBottomRightRadius: 8,
              }}>
              <SvgXml
                xml={VectorRed}
                height={120}
                width={100}
                style={{alignSelf: 'center'}}
              />
              <View
                style={{
                  borderBottomLeftRadius: 8,
                  borderBottomRightRadius: 8,
                  width: '100%',
                  height: 70,
                  alignItems: 'center',
                  justifyContent: 'center',
                  ...SHADOWS.light,
                  backgroundColor: COLORS.red,
                }}>
                <Text style={styles.p_text}>Cancelled</Text>
                <Text style={styles.txtgray}>
                  {cancelledCount ? cancelledCount : 0}
                </Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.85}
              onPress={() =>
                navigation.navigate('AudithList', {
                  params: {status_id: isStatusIdUp},
                })
              }
              style={{
                backgroundColor: COLORS.lightOrange,
                width: '48%',
                marginBottom: 15,
                alignItems: 'center',
                ...SHADOWS.light,
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                borderBottomLeftRadius: 8,
                borderBottomRightRadius: 8,
              }}>
              <SvgXml
                xml={VectorOrange}
                height={120}
                width={100}
                style={{alignSelf: 'center'}}
              />
              <View
                style={{
                  backgroundColor: COLORS.darkBule,
                  borderBottomLeftRadius: 8,
                  borderBottomRightRadius: 8,
                  width: '100%',
                  height: 70,
                  alignItems: 'center',
                  justifyContent: 'center',
                  // borderWidth: 1,
                  ...SHADOWS.light,
                }}>
                <Text style={styles.p_text}>Upcoming</Text>
                <Text style={styles.txtgray}>
                  {upcomingCount ? upcomingCount : 0}
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default Dashbord;
