import {
  View,
  Text,
  Image,
  SafeAreaView,
  ScrollView,
  StatusBar,
  Dimensions,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import React, {useState, useContext, useEffect} from 'react';
import {styles} from '../../../assets/css/MainStyles';
import {COLORS, FONT, SIZES} from '../../constants/themes';
import {PrimaryBtn} from '../../components/CustomButtom';
import {Input, PasswordBtn} from '../../components/CustomInput';
import {AuthContext} from '../../context/AuthContex';
import {SvgXml} from 'react-native-svg';
import Eye from '../../../assets/images/Eye';
import EyeClose from '../../../assets/images/EyeClose';
import {AUTH_BASE_URL, Token} from '../../constants/api';
import AsyncStorage from '@react-native-async-storage/async-storage';

const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;

const Login = ({navigation}) => {
  const [isLoading, setLoading] = useState(false);
  const [employeeId, setEmployeeId] = useState('');
  const [password, setPassword] = useState('');
  const [errorMobileNumber, setErrorMobileNumber] = useState(null);
  const [isSecure, setisSecure] = useState(true);
  const {userLogin, isUserLogged} = useContext(AuthContext);
  const [isAdminId, setAdminId] = useState([]);
  const [token] = useState(
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c',
  );

  // useEffect(() => {
  //   const fetchDataAsync = async () => {
  //     setLoading(true)
  //     const userDeviceTokan = await AsyncStorage.getItem("UserLoginStatus");
  //     setLoading(false)
  //     const transformedLoginData = JSON.parse(userDeviceTokan);
  //     console.log('transformedLoginData login in', transformedLoginData);
  //     // setDeviceTokan(transformedLoginData.deviceTokan)
  //   }
  //   fetchDataAsync();
  // }, [])

  // useEffect(() => {
  //   getAccessToken();
  // }, []);

  // const getAccessToken = async () => {
  //   try {
  //     setLoading(true);
  //     var myHeaders = new Headers();
  //     myHeaders.append("Authorization", "Basic YXBpdXNlcjp3ZWIk");
  //     myHeaders.append("Cookie", "sab=cad399a665e539ab233e7efc329ea2849f1252e8");

  //     var formdata = new FormData();
  //     formdata.append("email", employeeId);
  //     formdata.append("password", password);

  //     var requestOptions = {
  //       method: 'POST',
  //       headers: myHeaders,
  //       body: formdata,
  //       redirect: 'follow'
  //     };

  //     const response = await fetch("https://demo.crayoninfotech.com/adityabirla/api/auth/login/", requestOptions)
  //     const resJson = await response.json()

  //     setLoading(false);
  //     if (resJson.status === "success") {
  //       // setToken(resJson.token);
  //       // setAdminId(resJson.resJson[0].fldi_admin_id)
  //       isUserLogged()
  //       return;
  //     }
  //     console.log('response Token', resJson);
  //   } catch (error) {
  //     console.log('error from access token', error.message);
  //     // setMessage(error.message);
  //   }
  // };

  const handleLogin = async () => {
    if (!employeeId || !password) {
      // setLoading(true);
      // alert('Please enter vaild Email Id and Password');
      setErrorMobileNumber('Please enter vaild Email Id and Password');
      return;
    }
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', Token);

      var formdata = new FormData();
      formdata.append('email', employeeId);
      formdata.append('password', password);

      var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow',
      };

      const response = await fetch(
        'https://demo.crayoninfotech.com/adityabirla/api/auth/login',
        requestOptions,
      );
      const Json = await response.json();
      setLoading(false);

      // console.log('login response', Json);

      if (Json.status === 'success') {
        // alert(response.message)
        setTimeout(() => {
          AsyncStorage.setItem(
            'accessToken',
            JSON.stringify({
              accessToken: token,
            }),
          );
          AsyncStorage.setItem(
            'userDetauls',
            JSON.stringify({
              userDetauls: Json.result,
            }),
          );
          isUserLogged();
        }, 1000);
        // isUserLogged();
      } else {
        alert(Json.message);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const handlePassword = () => {
    setisSecure(!isSecure);
  };

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: COLORS.background}}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.white} />
      <ScrollView showsHorizontalScrollIndicator={false}>
        <View
          style={{
            paddingHorizontal: 20,
            paddingVertical: 35,
            marginTop: 100,
            // borderWidth:1
          }}>
          <Text style={styles.nameHeader}>Welcome!</Text>
          <Text style={styles.text}>
            Log in to access your audits and manage your assessments
            effortlessly.
          </Text>
        </View>
        <View
          style={{
            paddingHorizontal: 20,
            backgroundColor: COLORS.white,
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
          }}>
          <View
            style={{
              backgroundColor: COLORS.white,
              paddingVertical: 24,
            }}>
            <Input
              label="User Name"
              placeholder="Email ID"
              value={employeeId}
              setValue={setEmployeeId}
              autoCapitalize="none"
              keyboardType="name-phone-pad"
            />
            <Text
              style={{
                fontFamily: FONT.PoppinsRegular,
                fontSize: SIZES.medium,
                lineHeight: 18,
                marginBottom: 10,
                marginVertical: 10,
                color: COLORS.textBlack,
              }}>
              Password
            </Text>
            <View
              style={{
                height: 50,
                flexDirection: 'row',
                backgroundColor: COLORS.grayTextColor,
                borderRadius: 8,
                paddingHorizontal: 10,
                // borderWidth: 1,
                flex: 1,
                // marginRight: 10,
              }}>
              <TextInput
                style={{
                  flex: 1,
                  // borderWidth: 1,
                  fontFamily: FONT.PoppinsRegular,
                  fontSize: SIZES.font,
                  color: COLORS.black,
                  // marginRight: 10,
                }}
                placeholder="6 digits numbers"
                placeholderTextColor={COLORS.grey}
                onChangeText={setPassword}
                value={password}
                secureTextEntry={isSecure}
                keyboardType={'number-pad'}
                // maxLength={6}
              />
              <TouchableOpacity
                style={{alignSelf: 'center', margin: 5}}
                onPress={handlePassword}>
                {isSecure ? (
                  <SvgXml xml={EyeClose} height={20} width={20} />
                ) : (
                  <SvgXml xml={Eye} height={20} width={20} />
                )}
              </TouchableOpacity>
            </View>
            {errorMobileNumber ? (
              <Text style={styles.invalidTextMsg}>{errorMobileNumber}</Text>
            ) : null}
            <TouchableOpacity
              style={{alignItems: 'flex-end', margin: 8}}
              onPress={() => navigation.navigate('Forgot')}>
              <Text
                style={{
                  color: COLORS.primary,
                  fontFamily: FONT.PoppinsRegular,
                  fontSize: SIZES.small,
                  textDecorationLine: 'underline',
                  lineHeight: 18,
                }}>
                Forgot Password
              </Text>
            </TouchableOpacity>
            <View style={{flex: 1, marginVertical: 40}}>
              <PrimaryBtn
                btnText="Log In"
                onPress={handleLogin}
                // onPress={()=> console.log("Login data")}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default Login;
