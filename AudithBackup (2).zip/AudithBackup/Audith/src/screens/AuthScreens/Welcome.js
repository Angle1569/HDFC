import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  ScrollView,
  Image,
  StatusBar,
} from 'react-native';
import {COLORS, FONT, Logo, SIZES} from '../../constants/themes';
import {SvgXml} from 'react-native-svg';
import Rectangle from '../../../assets/images/Rectangle';
import {BtnWhite, PrimaryBtn} from '../../components/CustomButtom';

const Welcome = ({navigation}) => {
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: COLORS.background}}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.white} />
      <ScrollView showsHorizontalScrollIndicator={false}>
        <View style={styles.contain}>
          <SvgXml xml={Rectangle} height={280} width={345} />
          <Image
            source={require('../../../assets/images/logo.png')}
            style={{
              resizeMode: 'contain',
              alignSelf: 'center',
              position: 'absolute',
              marginTop: 48,
            }}
          />
          <View style={{alignItems: 'center'}}>
            <Text style={styles.text}>
              Empowering Audits, Enhancing Excellence
            </Text>
            <Text style={styles.text2}>
              Simplifying Audits for Seamless Operations
            </Text>
          </View>
        </View>
        <View style={{flex: 1, marginVertical: 80, marginHorizontal: 30}}>
          <PrimaryBtn
            btnText="LOG IN"
            onPress={() => navigation.navigate('Login')}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default Welcome;

const styles = StyleSheet.create({
  contain: {
    // marginHorizontal: 20,
    alignItems: 'center',
    marginTop: 100,
  },
  text: {
    marginTop: 20,
    alignItems: 'center',
    color: COLORS.textBlack,
    fontFamily: FONT.PoppinsRegular,
    fontSize: SIZES.extraLarge,
    fontWeight: '400',
  },
  text2: {
    color: COLORS.textBlack,
    fontFamily: FONT.PoppinsRegular,
    fontSize: SIZES.small,
    fontWeight: '400',
    alignSelf: 'center',
  },
});
