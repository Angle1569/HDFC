import React, {useState, useEffect} from 'react';
import {
  View,
  FlatList,
  Text,
  SafeAreaView,
  ScrollView,
  Image,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import {GET_BASE_URL, Token} from '../constants/api';
import {styles} from '../../assets/css/MainStyles';
import {BackHeader} from '../components/Header';
import {COLORS, FORM, SIZES, SHADOWS} from '../constants/themes';
import {SearchBar} from '../components/CustomInput';
import {SvgXml} from 'react-native-svg';
import Filter from '../../assets/images/Filter';
import Card from '../components/Card';
import {dashbordList} from '../constants/AllApiCall';
import {SecondaryBtn} from '../components/CustomButtom';
import Location from '../../assets/images/Location';
import Calendar from '../../assets/images/Calendar';
import Clock from '../../assets/images/Clock';

const AuditList = ({navigation, route}) => {
  const [data, setData] = useState([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [tabBar, setTabBar] = useState(1);
  const [search, setSearch] = useState('');
  const [auditList, setAuditList] = useState([]);
  const [onRefresh, setOnRefresh] = useState(false);
  const [progressId, setPrgressId] = useState(null);
  const [option, setOption] = useState([
    {
      id: 1,
      name: 'Today’s Audit',
      image: FORM,
    },
    {
      id: 2,
      name: 'Completed ',
      image: FORM,
      color: COLORS.lightGreen,
    },
    {
      id: 3,
      name: 'In Progress ',
      image: FORM,
      color: COLORS.lightBlue,
    },
    {
      id: 4,
      name: 'Cancelled Audit',
      image: FORM,
      color: COLORS.lightRed,
    },
    {
      id: 5,
      name: 'Upcoming Audit',
      image: FORM,
      color: COLORS.lightOrange,
    },
  ]);
  const [isActive, setActive] = useState('');
  // route.params.params.status_id
  const routeStatusId = route.params.params.status_id;
  console.log('route=====>', route.params.params.status_id);

  useEffect(() => {
    AuditList();
    fetchData();
  }, [AuditList, isActive]);

  const AuditList = async () => {
    try {
      setLoading(true);
      const respond = await dashbordList();
      setLoading(false);
      setAuditList(respond.result);
      // console.log('res-------->', respond.result);
      setPrgressId(respond.result[0].fldi_status_id);
    } catch (error) {
      console.log(error);
    }
  };

  const handleLoadMore = () => {
    // Increment the page count and fetch more data
    // if (!data.result) {
    //   setPage(prevPage => prevPage + 1);
    // }
    setPage(prevPage => prevPage + 1);
    fetchData();
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      var myHeaders = new Headers();
      myHeaders.append('Authorization', Token);

      var formdata = new FormData();
      formdata.append('page_no', page);
      formdata.append('status_id', isActive);

      var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow',
      };

      const respond = await fetch(
        'https://demo.crayoninfotech.com/adityabirla/api/common/auditlist',
        requestOptions,
      );

      const resJSON = await respond.json();
      // console.log('resJSON', resJSON.result);
      // setListStateId(resJSON.result.flg_audit_status);

      if (resJSON.status === 'success') {
        return setData(prevData => {
          if (page > 1) {
            return [...prevData, ...resJSON.result];
          }
          return [...resJSON.result];
        });
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderFooter = () => {
    if (loading) {
      return (
        <ActivityIndicator
          size="large"
          color="#ce211c"
          style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}
        />
      );
    }
  };

  const renderAudit = ({item, index}) => {
    if (!isActive) {
      return null;
    }

    const subcategories = data.filter(
      subcategory => subcategory.flg_audit_status === isActive,
    );

    // console.log('subdatttta=======>',subcategories);

    return (
      <View
        pointerEvents={onRefresh ? 'none' : 'auto'}
        style={{marginHorizontal: 20, marginBottom: 10}}>
        {subcategories.map(item => {
          return (
            <>
              <View
                key={item.fldi_id}
                style={{
                  // width: '100%',
                  // height: 200,
                  ...SHADOWS.light,
                  borderTopLeftRadius: 8,
                  borderTopRightRadius: 8,
                  backgroundColor: COLORS.white,
                }}>
                <View
                  style={{
                    padding: 16,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                  }}>
                  <Text style={styles.redtext}>
                    {item.branch_name ? item.branch_name : 'Bank Name'}
                  </Text>
                  <Text style={styles.textaudit}>Online Audit</Text>
                </View>
                <View
                  style={{
                    height: 1,
                    backgroundColor: COLORS.grayTextColor,
                    marginHorizontal: 16,
                  }}></View>
                <View>
                  <View
                    style={{
                      //   marginVertical: 16,
                      marginTop: 16,
                      marginHorizontal: 16,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      //   borderWidth: 1,
                    }}>
                    <Text style={styles.txt_head}>
                      {item.name_surname ? item.name_surname : 'Name Surname'}
                    </Text>
                    {/* <Text style={styles.text}>00 Members</Text> */}
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      marginHorizontal: 16,
                      //   borderWidth: 1,
                    }}>
                    <Text style={styles.text}>
                      {item.manager_name
                        ? item.manager_name
                        : 'Branch Manager Name'}
                    </Text>
                    {/* <Text style={styles.text}>Actionable Count</Text> */}
                  </View>
                </View>

                <View
                  style={{
                    height: 1,
                    backgroundColor: COLORS.grayTextColor,
                    marginHorizontal: 16,
                    marginTop: 16,
                  }}></View>
                <View
                  style={{
                    flexDirection: 'row',
                    marginHorizontal: 16,
                    marginVertical: 16,
                    gap: 5,
                  }}>
                  <SvgXml xml={Location} height={20} width={20} />
                  <Text style={styles.text}>{item.branch_name} </Text>
                  <SvgXml xml={Calendar} height={20} width={20} />
                  <Text style={styles.text}>{item.fldd_audit_date} </Text>
                  <SvgXml xml={Clock} height={20} width={20} />
                  <Text style={styles.text}>{item.fldti_audit_time}</Text>
                </View>
              </View>
              {item.flg_audit_status === '4' ? (
                <>
                  <SecondaryBtn
                    onPress={() => navigation.navigate('QuestionScreen')}
                    btnText="Start Audit"
                  />
                </>
              ) : null}
            </>
          );
        })}
      </View>
    );
  };

  const handleClick = auditId => {
    setPrgressId(auditId);
    setActive(auditId);
  };

  // console.log(isActive);

  const ProgressDetail = () => {
    return (
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {auditList.map(status => {
          let isActiveData = status.fldi_status_id === route.params.params.status_id;
          return (
            <TouchableOpacity
              key={status.fldi_id}
              activeOpacity={0.6}
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                // borderColor: COLORS.bordercolor,
                backgroundColor: isActiveData ? COLORS.lightRed : COLORS.white,
                borderColor: isActiveData
                  ? COLORS.lightBlue
                  : COLORS.bordercolor,
                borderRadius: 16,
                borderWidth: 1,
                marginHorizontal: 8,
                paddingHorizontal: 30,
                paddingVertical: 20,
              }}
              onPress={() => handleClick(status.fldi_status_id)}>
              <Image
                source={require('../../assets/images/complete.png')}
                style={{height: 32, width: 32, marginVertical: 8}}
              />
              <Text
                style={{
                  fontSize: SIZES.font,
                  color: COLORS.textBlack,
                }}>
                {status.fldv_name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    );
  };

  return (
    <SafeAreaView style={{backgroundColor: COLORS.white}}>
      <BackHeader
        onPress={() => {
          navigation.goBack();
        }}
      />
      {ProgressDetail()}
      <View
        style={{
          marginVertical: 20,
          marginHorizontal: 20,
          flexDirection: 'row',
          // borderWidth:1 ,
        }}>
        <SearchBar
          placeholder={'Search for Bank Name'}
          value={search}
          setValue={setSearch}
        />
        <View
          style={{
            backgroundColor: COLORS.grayTextColor,
            padding: 10,
            borderRadius: 8,
          }}>
          <TouchableOpacity>
            <SvgXml xml={Filter} height={30} width={30} />
          </TouchableOpacity>
        </View>
      </View>
      <FlatList
        data={data}
        showsVerticalScrollIndicator={false}
        // renderItem={({item}) => (
        //   <Item title={item.branch_name} id={item.fldi_id} />
        // )}
        onRefresh={onRefresh}
        renderItem={renderAudit}
        // keyExtractor={item => item.fldi_id}
        ListFooterComponent={renderFooter}
        // onEndReached={handleLoadMore}
        onEndReachedThreshold={0.1}
      />
    </SafeAreaView>
  );
};

export default AuditList;

// import * as React from 'react';
// import {View, useWindowDimensions, SafeAreaView} from 'react-native';
// import {TabView, SceneMap} from 'react-native-tab-view';
// import CustomTabBar from '../components/CustomeTab';
// import {COLORS} from '../constants/themes';
// import {BackHeader} from '../components/Header';

// const AuditList = ({navigation, route}) => {
//   console.log('route name--->', route.params.params.status_id);

//   const FirstRoute = () => (
//     <View style={{flex: 1, backgroundColor: '#ff4081'}} />
//   );

//   const SecondRoute = () => (
//     <View style={{flex: 1, backgroundColor: '#673ab7'}} />
//   );

//   const ThirdRoute = () => (
//     <View style={{flex: 1, backgroundColor: COLORS.lightBlue}} />
//   );

//   const FourRoute = () => (
//     <View style={{flex: 1, backgroundColor: COLORS.green}} />
//   );

//   const FiveRoute = () => (
//     <View style={{flex: 1, backgroundColor: COLORS.grey}} />
//   );

//   // const renderScene = SceneMap({
//   //   first: FirstRoute,
//   //   second: SecondRoute,
//   //   third: ThirdRoute,
//   //   four: FourRoute,
//   //   five: FiveRoute,
//   // });

//   const renderScene = ({route}) => {
//     switch (route.key) {
//       case 'first':
//         return <FirstRoute />;
//       case 'second':
//         return <SecondRoute />;
//       case 'third':
//         return <ThirdRoute />;
//       case 'four':
//         return <FourRoute />;
//       case 'five':
//         return <FiveRoute />;
//       default:
//         return null;
//     }
//   };
//   // const layout = useWindowDimensions();

//   // const translateY = React.useRef(new Animated.Value(-300)).current;

//   // React.useEffect(() => {
//   //   Animated.timing(translateY, {
//   //     toValue: -300,
//   //     duration: 500,
//   //     useNativeDriver: true,
//   //   }).start();
//   // }, [translateY]);

//   const [routes, setRoutes] = React.useState([
//     {key: 'first', title: 'Total Audit', color: COLORS.lightYellow},
//     {key: 'second', title: 'Completed', color: COLORS.lightGreen},
//     {key: 'third', title: 'In Progress', color: COLORS.lightBlue},
//     {key: 'four', title: 'Cancelled', color: COLORS.lightRed},
//     {key: 'five', title: 'Up Comming', color: COLORS.lightOrange},
//   ]);

//   React.useEffect(() => {
//     setRoutes([
//       {
//         key: 'first',
//         title: 'Total Audit',
//         color: COLORS.lightYellow,
//       },
//       {
//         key: 'second',
//         title: 'Completed',
//         color: COLORS.lightGreen,
//       },
//       {
//         key: 'third',
//         title: 'In Progress',
//         color: COLORS.lightBlue,
//       },
//       {
//         key: 'four',
//         title: 'Cancelled',
//         color: COLORS.lightRed,
//       },
//       {
//         key: 'five',
//         title: 'Up Comming',
//         color: COLORS.lightOrange,
//       },
//     ]);
//   }, []);

//   const [index, setIndex] = React.useState([
//     route?.params?.params.status_id === 'Total Audit'
//       ? 0
//       : route?.params?.params.status_id === 'Completed'
//       ? 1
//       : route?.params?.params.status_id === 'In Progress'
//       ? 2
//       : route?.params?.params.status_id === 'Cancelled'
//       ? 3
//       : route?.params?.params.status_id === 'Up Comming'
//       ? 4
//       : 0,
//   ]);
//   // console.log('route=====>', index);

//   // const [index, setIndex] = React.useState(0);

//   return (
//     <SafeAreaView style={{backgroundColor: COLORS.white}}>
//       <BackHeader
//         onPress={() => {
//           navigation.goBack();
//         }}
//       />
//       <View style={{height: '100%'}}>
//         <TabView
//           navigationState={{index, routes}}
//           renderScene={renderScene}
//           onIndexChange={setIndex}
//           // initialLayout={{ width: layout.width }}
//           renderTabBar={props => <CustomTabBar {...props} />}
//         />
//       </View>
//     </SafeAreaView>
//   );
// };

// export default AuditList;
