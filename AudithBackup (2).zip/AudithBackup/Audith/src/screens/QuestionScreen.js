import React, {useState, useEffect, useRef} from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  PermissionsAndroid,
  Platform,
  Image,
} from 'react-native';
import {BackHeader} from '../components/Header';
import {COLORS, SIZES} from '../constants/themes';
import {BtnWhite, ImageBtn, PrimaryBtn} from '../components/CustomButtom';
import {styles} from '../../assets/css/MainStyles';
import {SvgXml} from 'react-native-svg';
import img from '../../assets/images/img';
import Radio from '../../assets/images/Radio';
import RadioRed from '../../assets/images/RadioRed';
import ImageOverlay from 'react-native-image-overlay';
import * as ImagePicker from 'react-native-image-crop-picker';
import Geolocation from '@react-native-community/geolocation';
import {GET_BASE_URL, Token} from '../constants/api';
import {questionTitle} from '../constants/AllApiCall';
import {useIsFocused} from '@react-navigation/native';

const QuestionScreen = ({navigation, route}) => {
  const [isLoading, setLoading] = useState(false);
  const [selectedValue, setSelectedValue] = useState(null);
  const [image, setImage] = useState('');
  const [isFileData, setFileData] = useState(null);
  const [dateTime, setDateTime] = useState(null);
  const [question, setQuestion] = useState('');
  const [questionId, setQuestionId] = useState('');
  const [branchId, setbranchId] = useState('');
  const [adminId, setAdminId] = useState('');
  const [gps, setGps] = useState(null);
  const isFocused = useIsFocused();
  // const {previousData} = route.params;

  useEffect(() => {
    // setImage(null)
    auditCreate();
  }, [auditCreate, isFocused]);

  const auditCreate = async () => {
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', Token);

      var formdata = new FormData();
      formdata.append('branch_id', branchId);
      formdata.append('admin_id', adminId);

      var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow',
      };

      const response = await fetch(
        'https://demo.crayoninfotech.com/adityabirla/api/auth/create_audit',
        requestOptions,
      );
      const resJson = await response.json();
      setLoading(false);
      setbranchId(resJson.result.fldi_branch_id);
      setAdminId(resJson.result.fldi_admin_id);

      // console.log('==========>', adminId, branchId)
    } catch (error) {
      console.log(error.message);
    }
  };

  useEffect(() => {
    requestLocationPermission();
    questionData();
  }, []);

  const questionData = async () => {
    try {
      setLoading(true);
      const response = await questionTitle();
      setLoading(false);
      if (response.status === 'success') {
        setQuestion(response.result[0].fldv_title);
        setQuestionId(response.result[0].fldi_id);
        // console.log("id", questionId)
      } else {
        console.log(response.message);
      }
    } catch (error) {
      console.log(error.message);
    }
  };

  const requestLocationPermission = async () => {
    if (Platform.OS === 'ios') {
      getCurrentPosition();
    } else {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: 'Location Access Required',
            message: 'This App needs to Access your location',
          },
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          //To Check, If Permission is granted
          getCurrentPosition();
        } else {
          alert('Permission Denied');
        }
      } catch (error) {
        console.log(error);
      }
    }
  };

  const getCurrentPosition = () => {
    Geolocation.getCurrentPosition(
      position => {
        // setLocation(position.coords);
        // setLoading(false)
        // console.log('position', position.coords.latitude);
        setGps(position);
      },
      error => {
        console.error(error.code, error.message);
      },
    );
  };

  const gpsComponent = (
    <View style={styles.gps}>
      {gps ? (
        <View>
          <Text style={{color: 'white', fontSize: SIZES.base}}>{dateTime}</Text>
          <Text style={{color: COLORS.white, fontSize: SIZES.base}}>
            LAT: {gps.coords.latitude}
          </Text>
          <Text style={{color: COLORS.white, fontSize: SIZES.base}}>
            LNG: {gps.coords.longitude}
          </Text>
        </View>
      ) : (
        <View>
          <Text>Waiting</Text>
        </View>
      )}
    </View>
  );

  const onCapture = async type => {
    ImagePicker.openCamera({
      mediaType: type,
      width: 250,
      height: 250,
      cropping: true,
      quality: 0.5,
      includeBase64: false,
    })
      .then(image => {
        const fileName = image.path.split('/').pop();
        const img = {
          uri: image.path,
          name: fileName,
          type: image.mime,
        };
        console.log('img:', img);
        console.log('setFileData:', image.path);
        setFileData(img);
        setImage(image.path);
        const currentDateTime = new Date().toLocaleString();

        setDateTime(currentDateTime);

        // console.log('--->', JSON.stringify(img));
      })
      .catch(er => {
        console.log(er);
        alert(er);
        if (er.code === 'E_PICKER_CANCELLED') {
          // here the solution
          return false;
        }
      });
  };

  const CustomRadioButton = ({label, selected, onSelect}) => (
    <TouchableOpacity
      style={[
        styles.radioButton,
        {borderColor: selected ? COLORS.primary : COLORS.textGray},
      ]}
      onPress={onSelect}>
      <View style={{flexDirection: 'row', gap: 5}}>
        {selected ? (
          <SvgXml
            xml={RadioRed}
            height={16}
            width={16}
            style={{alignSelf: 'center'}}
          />
        ) : (
          <SvgXml
            xml={Radio}
            height={16}
            width={16}
            style={{alignSelf: 'center'}}
          />
        )}
        <Text
          style={[
            styles.text,
            {
              color: selected ? COLORS.primary : COLORS.textGray,
              alignSelf: 'center',
            },
          ]}>
          {label}
        </Text>
      </View>
    </TouchableOpacity>
  );

  const handleNext = async () => {
    if (!image && !selectedValue) {
      alert('Upload image');
      console.log('error');
      return;
    }
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', 'Basic YXBpdXNlcjp3ZWIk');
      myHeaders.append(
        'Cookie',
        'sab=ed85366fda3d6215c6eef45803c2a086ce127991',
      );

      var formdata = new FormData();
      formdata.append('audit_id', branchId);
      formdata.append('admin_id', adminId);
      formdata.append('ques_id', questionId);
      formdata.append('ans', selectedValue);
      formdata.append('image', isFileData, image);

      var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow',
      };

      const response = await fetch(
        'https://demo.crayoninfotech.com/adityabirla/api/auth/add_audit',
        requestOptions,
      );

      const resJson = await response.json();
      setLoading(false);
      console.log('addImage', resJson);

      if (resJson.status === 'success') {
        // alert(Json.message);
        setImage(image);
        setSelectedValue(selectedValue);
        navigation.navigate('Question2', {
          params: {question: image, answer: selectedValue},
        });
        setImage('');
        setSelectedValue('');
        // setAnswers(prevAnswers => [
        //   ...prevAnswers,
        //   {question: image, answer: selectedValue},
        // ]);
      } else {
        alert(Json.message);
      }
      
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <View style={{flex: 1, backgroundColor: COLORS.background}}>
      <BackHeader onPress={() => navigation.goBack()} />
      <ScrollView
        keyboardShouldPersistTaps={'always'}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{flexGrow: 1}}>
        <View
          style={{
            paddingHorizontal: 20,
            paddingVertical: 35,
          }}>
          <Text style={styles.nameHeader}>Capture A Image</Text>
          <Text style={styles.text}>
            Use the camera to capture images relevant to this audit. Ensure
            clarity and focus for better assessment.
          </Text>
        </View>
        <View
          style={{
            paddingVertical: 20,
            paddingHorizontal: 20,
            backgroundColor: COLORS.white,
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
          }}>
          {question.length > 0 && (
            <>
              <Text key={question.fldi_id} style={styles.q_text}>
                {question}
              </Text>
              <View
                style={{
                  flexDirection: 'row',
                  gap: 20,
                  marginTop: 16,
                  marginBottom: 30,
                }}>
                <CustomRadioButton
                  label="Yes"
                  selected={selectedValue === 'Yes'}
                  onSelect={() => setSelectedValue('Yes')}
                />
                <CustomRadioButton
                  label="No"
                  selected={selectedValue === 'No'}
                  onSelect={() => setSelectedValue('No')}
                  onPress
                />
              </View>

              {image ? (
                <ImageOverlay
                  source={{uri: image}}
                  height={150}
                  containerStyle={{width: '100%'}}
                  contentPosition="bottom"
                  overlayAlpha={0.1}>
                  {gpsComponent}
                </ImageOverlay>
              ) : (
                <View
                  style={{
                    backgroundColor: COLORS.Redcolor,
                    paddingVertical: 24,
                    borderWidth: 1,
                    borderStyle: 'dashed',
                    borderColor: COLORS.primary,
                    borderRadius: 5,
                    height: 120,
                    alignItems: 'center',
                  }}>
                  <SvgXml xml={img} height={30} width={30} />
                  <Text style={[styles.text, {margin: 10}]}>Capture Image</Text>
                </View>
              )}
              <View style={{marginVertical: 16}}>
                <ImageBtn
                  source={require('../../assets/images/Camera.png')}
                  btnText={'Capture image'}
                  // onPress={() => onCapture('photo')}
                  onPress={() => {
                    onCapture('photo');
                  }}
                />
              </View>
              <View style={{width: '50%', marginTop: 60, marginLeft: '50%'}}>
                <PrimaryBtn
                  btnText={'Next'}
                  // onPress={() => navigation.navigate('Question2')}
                  onPress={handleNext}
                />
              </View>
            </>
          )}

          {/* <View style={{flexDirection: 'row', gap: 5, marginTop: 60}}> */}
          {/* <BtnWhite
              source={require('../../assets/images/Eye.png')}
              onPress={() => navigation.navigate('QuestionScreen')}
              btnText={'Previous '}
            /> */}

          {/* </View> */}
        </View>
      </ScrollView>
    </View>
  );
};

export default QuestionScreen;
