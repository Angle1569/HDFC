import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
} from 'react-native';

const AuditList = () => {
  const [isLoading, setLoading] = useState(false);
  const [isCategory, setCategory] = useState([]);
  const [isCategoryId, setCategoryId] = useState(null);
  const [isSubcategory, setSubcategory] = useState([]);  
  const [isActive, setActive] = useState('');
  
  useEffect(() => {
    getData();
    AuditList();
  }, []);

  const getData = async () => {
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', 'Basic YXBpdXNlcjp3ZWIk');

      var requestOptions = {
        method: 'GET',
        headers: myHeaders,
        redirect: 'follow',
      };

      const respond = await fetch(
        'https://demo.crayoninfotech.com/adityabirla/api/common/dashboardstatus',
        requestOptions,
      );
      const resJSON = await respond.json();
      setLoading(false);
      // console.log(resJSON);
      setCategory(resJSON.result);
      // setSubcategory(resJSON.Subcategory);
      setCategoryId(resJSON.result[0].fldi_status_id);
      // setActive(resJSON.Category[0].fldi_cat_id);
    } catch (error) {
      console.log(error);
    }
  };

  const AuditList = async () => {
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', 'Basic YXBpdXNlcjp3ZWIk');
      
      var formdata = new FormData();
      formdata.append('page_no', '1');
      formdata.append('status_id', isCategory);

      var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow',
      };

      const response = await fetch(
        'https://demo.crayoninfotech.com/adityabirla/api/common/auditlist',
        requestOptions,
      );
      const resJSON = await response.json();
      console.log('id---', resJSON);
      setSubcategory(resJSON.result);
    } catch (error) {
      console.log(error);
    }
  };

  const handleCategoryClick = categoryId => {
    setCategoryId(categoryId);
    setActive(categoryId);
  };

  console.log(isCategoryId);

  const TitleHead = () => {
    return (
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        {isCategory.map(category => {
          let isActiveData = category.fldi_status_id === isActive;
          return (
            <TouchableOpacity
              onPress={() => handleCategoryClick(category.fldi_status_id)}
              key={category.fldi_cat_id}
              style={{
                padding: 10,
                borderWidth: 1,
                borderColor: 'red',
                backgroundColor: isActiveData ? 'yellow' : 'pink',
              }}>
              <Text style={{color: isActiveData ? 'black' : 'blue'}}>
                {category.fldv_name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    );
  };

  const renderSubcategories = () => {
    if (!isCategoryId) {
      return null;
    }

    const subcategories = isSubcategory.filter(
      subcategory => subcategory.fldi_parent_cat_id === isCategoryId,
    );

    console.log(subcategories);

    return (
      <View>
        {subcategories.map(subcategory => (
          <View key={subcategory.sub_category_id}>
            <Text>{subcategory.fldv_subcat_name}</Text>
            <Text>Description: {subcategory.fldi_desc}</Text>
          </View>
        ))}
      </View>
    );
  };

  return (
    <View>
      <Text>App</Text>
      <TitleHead />
      {renderSubcategories()}
    </View>
  );
};

export default AuditList;

const styles = StyleSheet.create({});