export const COLORS = {
  primary: '#AB1E24',
  textBlack: '#323232',
  textGray: '#676767',
  green: '#73EC95',
  yellow: '#FFD35E',
  blue: '#A2D3FF',
  red: '#FFA4A7',
  darkBule: '#FF9969',
  background: '#FDEECF',
  bordercolor: '#F4F4F4',
  light: '#D7D7D7',

  lightYellow: '#FFF7E4',
  lightGreen: '#D2FFDF',
  lightBlue: '#ECF6FF',
  lightRed: '#FFE2E3',
  lightOrange: '#FFDFCF',
  Redcolor: '#FFEEEF',
  grayTextColor: '#F0F0F0',
  white: '#FFFFFF',
  black: '#000000',
  grey: '#74858C',
  lightprimary: '#fce6ed',
};

export const SIZES = {
  base: 10,
  small: 12,
  font: 14,
  medium: 16,
  large: 18,
  mediumLarge: 20,
  extraLarge: 24,
  xl: 32,
  xxl: 40,
  xxxl: 80,
};

export const FONT = {
  PoppinsBlack: 'Poppins-Black',
  PoppinsBold: 'Poppins-Bold',
  PoppinsExtraBold: 'Poppins-ExtraBold',
  PoppinsRegular: 'Poppins-Regular',
  PoppinsMedium: 'Poppins-Medium',
  PoppinsSemiBold: 'Poppins-SemiBold',
  PoppinsThin: 'Poppins-Thin',
};

export const SHADOWS = {
  light: {
    shadowColor: '#676767',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.29,
    shadowRadius: 3.11,
    elevation: 6,
  },
  lightRed: {
    shadowColor: '#FFE2E3',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.29,
    shadowRadius: 2.11,
    elevation: 2,
  },
};

//image
export const Menu_Bar = require('../../assets/images/menu.png');
// export const Auditor = require('../../assets/images/auditor.png');
export const Logo = require('../../assets/images/logo.png');
// export const Dashbord_Heroic = require('../../assets/images/Group118.png');
export const ADD_ICON = require('../../assets/images/start.png');
export const CROSS_ICON = require('../../assets/images/addalt.png');
export const CALENDAR = require('../../assets/images/calendar-date.png');
export const CLOCK = require('../../assets/images/clock.png');
export const DASHBOARD = require('../../assets/images/dashboard.png');
export const HOME_ICON = require('../../assets/images/Glance.png');
// export const ADD_ICON_ACTIVE = require('../../assets/images/plus-alt.png');
export const PROFILE_ICON = require('../../assets/images/ProfileImg.png');
export const PROFILE_ICON_ACTIVE = require('../../assets/images/ProfileImg.png');
export const ARROW = require('../../assets/images/arrow-down.png');
export const DOWNARROW = require('../../assets/images/arrow-ios-downward-outline.png');
export const CHECKED_ICON = require('../../assets/images/Group117.png');
export const UNCHECKED_ICON = require('../../assets/images/Ellipse435.png');
export const GALLERY = require('../../assets/images/image-gallery.png');
export const CAMERA = require('../../assets/images/Camera.png');
export const AVTERYELLOW = require('../../assets/images/bro.png');
export const FORM = require('../../assets/images/complete.png');
