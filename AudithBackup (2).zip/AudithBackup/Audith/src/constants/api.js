export const AUTH_BASE_URL = 'https://demo.crayoninfotech.com/adityabirla//api/auth/'
export const Token = 'Basic YXBpdXNlcjp3ZWIk'
export const Cookie = 'sab=9ae872a9e0681bcf0851e2bee48599cb031b7bef'
export const GET_BASE_URL = 'https://demo.crayoninfotech.com/adityabirla/api/common/'

// https://demo.crayoninfotech.com/adityabirla/api/auth/login