import { AUTH_BASE_URL, Cookie, GET_BASE_URL, Token } from "./api";

export const questionTitle = async () => {
    try {
        var myHeaders = new Headers();
        myHeaders.append("Authorization", Token);

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        const respond = await fetch(GET_BASE_URL + "questionlist", requestOptions)
        const resJson = await respond.json()
        return resJson;

    } catch (error) {
        console.log(error);
    }
};

export const createAuditId = async (branchId, adminId) => {
    try {
        var myHeaders = new Headers();
        myHeaders.append("Authorization", Token);
        myHeaders.append("Cookie", Cookie);

        var formdata = new FormData();
        formdata.append("branch_id", branchId);
        formdata.append("admin_id", adminId);

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow'
        };

        const respond = await fetch(AUTH_BASE_URL + "create_audit", requestOptions);
        const reJson = await respond.json();
        return reJson;

    } catch (error) {
        console.log(error);
    }

};

export const dashbordCountList = async (statusId) => {
    try {
        var myHeaders = new Headers();
        myHeaders.append("Authorization", Token);
        myHeaders.append("Cookie", "sab=a7b4af441847f7698a83262304d774cd11074d1a");

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        const respond = await fetch(GET_BASE_URL + `dashboard?status_id=${statusId}`, requestOptions)
        const reJson = await respond.json();
        return reJson;

    } catch (error) {
        console.log(error);
    }

};

export const dashbordList = async () => {
    try {
        var myHeaders = new Headers();
        myHeaders.append("Authorization", "Basic YXBpdXNlcjp3ZWIk");
        myHeaders.append("Cookie", "sab=a7b4af441847f7698a83262304d774cd11074d1a");

        var requestOptions = {
            method: 'GET',
            headers: myHeaders,
            redirect: 'follow'
        };

        const respond = await fetch(GET_BASE_URL + "dashboardstatus", requestOptions)
        const reJson = await respond.json();
        return reJson;

    } catch (error) {
        console.log(error);
    }
};


