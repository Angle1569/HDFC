import React, {useEffect, createContext, useState} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const AuthContext = createContext();

const AuthProvider = ({children}) => {
  const [isLoading, setLoading] = useState(false);
  const [userTokan, setUserTokan] = useState(null);
  const [isUserLoginStatus, setUserLoginStatus] = useState(false);
  const [isUserStatus, setUserStatus] = useState('');

  // const userLogin = async () => {
  //   setLoading(true);
  //   AsyncStorage.setItem('userData', Token);
  //   setUserTokan(Token);
  //   setLoading(false);
  //   console.log('login');
  // };

  // const userLogin = async (Token, employeeId, password) => {
  //   setLoading(true);
  //   try {
  //     var myHeaders = new Headers();
  //     myHeaders.append('Authorization', Token);

  //     var formdata = new FormData();
  //     formdata.append('email', employeeId);
  //     formdata.append('password', password);

  //     var requestOptions = {
  //       method: 'POST',
  //       headers: myHeaders,
  //       body: formdata,
  //       redirect: 'follow',
  //     };

  //     const response = await fetch(
  //       'https://demo.crayoninfotech.com/adityabirla/api/auth/login',
  //       requestOptions,
  //     );
  //     const Json = await response.json();
  //     setLoading(false);
  //     // console.log("Authcontext===", Json);
  //     // if (Json.status === 'success') {
  //     //   AsyncStorage.setItem(
  //     //     'userData',
  //     //     JSON.stringify({
  //     //       userTokan: Json.result,
  //     //     })
  //     //   )
  //     //   setUserTokan(Json.result)
  //     // } else {
  //     //   console.log("login error",Json.message);
  //     // }
  //     return Json;
  //   } catch (error) {
  //     console.log(error.message);
  //   }
  // };

  useEffect(() => {
    isUserLogged();
  }, []);

  const isUserLogged = async () => {
    // try {
    //   let UserLoginStatus = await AsyncStorage.getItem('UserLoginStatus')
    //   if (!UserLoginStatus) {
    //     // Alert.alert("Unable to fetch mobile number, Login again");
    //     return;
    //   }
    //   const transformedLoginData = JSON.parse(UserLoginStatus);

    //   console.log('transformedLoginData AuthContext--->', transformedLoginData);
    //   setUserLoginStatus(transformedLoginData.UserLoginStatus)

    // } catch (error) {
    //   console.log(`isUserLogged in ${error}`);
    // }
    setLoading(true);
    let userTokan = await AsyncStorage.getItem('accessToken');
    setLoading(false);
    // console.log('isAccessToken Async--->', userTokan );
    setUserTokan(userTokan);
  };

  const userLogout = () => {
    setLoading(true);
    AsyncStorage.removeItem('accessToken');
    // AsyncStorage.removeItem('UserLoginStatus');
    setUserTokan(null);
    // setUserLoginStatus(null);
    setLoading(false);
    console.log('logout');
  };

  return (
    <AuthContext.Provider
      value={{
        userLogout,
        isLoading,
        userTokan,
        isUserLogged,
      }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
