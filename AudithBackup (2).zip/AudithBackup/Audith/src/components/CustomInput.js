import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Image,
  TouchableOpacity,
} from 'react-native';
import {COLORS, FONT, SIZES} from '../constants/themes';
import {SvgXml} from 'react-native-svg';
import Search from '../../assets/images/Search';
import Eye from '../../assets/images/Eye';

export const Input = ({
  props,
  name,
  maxLength,
  placeholder,
  value,
  setValue,
  keyboardType,
  secureTextEntry = false,
  placeholderTextColor,
  autoCapitalize,
  label,
}) => {
  return (
    <>
      <Text style={styles.inputLabel}>{label}</Text>
      <View style={styles.inputBox}>
        <TextInput
          style={styles.inputStyle}
          placeholder={placeholder}
          placeholderTextColor={COLORS.grey}
          onChangeText={text => setValue(text)}
          value={value}
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          // keyboardType='name-phone-pad'
          maxLength={maxLength}
          autoCapitalize={autoCapitalize}
        />
      </View>
    </>
  );
};

export const PasswordBtn = ({
  props,
  name,
  maxLength,
  placeholder,
  value,
  setValue,
  keyboardType,
  secureTextEntry = false,
  placeholderTextColor,
  autoCapitalize,
  label,
}) => {
  return (
    <>
      <View style={styles.searchBox}>
        <TextInput
          style={styles.inputStyle}
          placeholder={placeholder}
          placeholderTextColor={COLORS.grey}
          onChangeText={text => setValue(text)}
          value={value}
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          maxLength={maxLength}
          autoCapitalize={autoCapitalize}
        />
        <TouchableOpacity style={{alignSelf: 'center'}} onPress={() => console.log('Press')}>
          <SvgXml xml={Eye} height={20} width={20} />
        </TouchableOpacity>
      </View>
    </>
  );
};

export const SearchBar = ({
  props,
  name,
  maxLength,
  placeholder,
  value,
  setValue,
  keyboardType,
  secureTextEntry = false,
  placeholderTextColor,
  autoCapitalize,
  label,
}) => {
  return (
    <>
      <View style={styles.searchBox}>
        <TextInput
          style={styles.inputStyle}
          placeholder={placeholder}
          placeholderTextColor={COLORS.grey}
          onChangeText={text => setValue(text)}
          value={value}
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          maxLength={maxLength}
          autoCapitalize={autoCapitalize}
        />
        <SvgXml
          xml={Search}
          height={24}
          width={24}
          style={{alignSelf: 'center'}}
        />
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  inputLabel: {
    fontFamily: FONT.PoppinsRegular,
    fontSize: SIZES.medium,
    lineHeight: 18,
    marginBottom: 10,
    // marginHorizontal: 10,
    marginVertical: 10,
    color: COLORS.textBlack,
    // borderWidth: 1,
  },
  inputBox: {
    height: 45,
    width: '100%',
    backgroundColor: COLORS.grayTextColor,
    borderColor: COLORS.grey,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  searchBox: {
    height: 50,
    flexDirection: 'row',
    // width: '80%',
    backgroundColor: COLORS.grayTextColor,
    borderRadius: 8,
    // justifyContent: 'center',
    paddingHorizontal: 10,
    // marginBottom: 2,
    // borderWidth: 1,
    flex: 1,
    marginRight: 10,
  },
  inputStyle: {
    // width: '100%',
    flex: 1,
    // borderWidth: 1,
    fontFamily: FONT.PoppinsRegular,
    fontSize: SIZES.font,
    color: COLORS.black,
    marginRight: 10,
    // alignItems: 'center'
    // borderWidth: 1
  },
});
