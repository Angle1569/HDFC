import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Modal,
  Image,
} from 'react-native';
import {COLORS, CROSS_ICON, FONT, SHADOWS, SIZES} from '../constants/themes';
import LinearGradient from 'react-native-linear-gradient';

export const PrimaryBtn = ({onPress, btnText, disabled}) => {
  return (
    <LinearGradient
      colors={['#AB1E24', '#F07033', '#F07033']}
      style={{borderRadius: 8}}
      start={{x: 0, y: 0}}
      end={{x: 1, y: 0}}>
      <TouchableOpacity
        style={styles.primaryBtn}
        onPress={onPress}
        disabled={disabled}>
        <Text style={styles.primaryBtnText}>{btnText}</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};

export const SecondaryBtn = ({onPress, btnText, disabled}) => {
  return (
    <LinearGradient
      colors={['#AB1E24', '#F07033', '#F07033']}
      style={{
        borderBottomLeftRadius: 8,
        borderBottomRightRadius: 8,
        // ...SHADOWS.light,
      }}
      start={{x: 0, y: 0}}
      end={{x: 1, y: 0}}>
      <TouchableOpacity
        style={styles.primaryBtn}
        onPress={onPress}
        disabled={disabled}>
        <Text style={styles.primaryBtnText}>{btnText}</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};

export const ImageBtn = ({onPress, btnText, disabled, source}) => {
  return (
    <LinearGradient
      colors={['#AB1E24', '#F07033', '#F07033']}
      style={{borderRadius: 8}}
      start={{x: 0, y: 0}}
      end={{x: 1, y: 0}}>
      <TouchableOpacity
        style={[
          styles.primaryBtn,
          {flexDirection: 'row', justifyContent: 'center', gap: 5},
        ]}
        onPress={onPress}
        disabled={disabled}>
        <Image
          source={source}
          style={{height: 20, width: 20, resizeMode: 'contain', top: 4}}
        />
        <Text style={styles.primaryBtnText}>{btnText}</Text>
      </TouchableOpacity>
    </LinearGradient>
  );
};

export const BtnWhite = ({onPress, btnText, disabled, source}) => {
  return (
    <TouchableOpacity
      style={[
        styles.primaryBtn,
        {flexDirection: 'row', justifyContent: 'center', gap: 5, width: '50%', borderRadius:8, backgroundColor: COLORS.white},
      ]}
      onPress={onPress}
      disabled={disabled}>
      <Image
        source={source}
        style={{height: 20, width: 20, resizeMode: 'contain', top: 4}}
      />
      <Text style={styles.BlackBtnText}>{btnText}</Text>
    </TouchableOpacity>
  );
};
export const CancelBtn = props => {
  const {popup, togglePopUp, reason, setreason, onPress} = props;
  return (
    <Modal animationType="slide" transparent={true} visible={popup}>
      <View
        style={{
          flex: 1,
          position: 'absolute',
          backgroundColor: 'rgba(100,100,100, 0.8)',
          height: '100%',
          width: '100%',
        }}>
        <View
          style={{
            justifyContent: 'space-between',
            marginTop: '50%',
            backgroundColor: '#fff',
            marginHorizontal: 10,
            padding: 20,
            height: 300,
            borderRadius: 20,
          }}>
          <View style={{alignItems: 'center'}}>
            <Text style={{color: COLORS.primary, fontSize: 26}}>
              Cancel Audit
            </Text>
            <TouchableOpacity
              onPress={() => togglePopUp()}
              style={{position: 'absolute', right: 1}}>
              <Image source={CROSS_ICON} />
            </TouchableOpacity>
          </View>
          <Text style={{color: '#000', fontSize: 18}}>
            Let us know why you want to cancel the audit.
          </Text>
          <TextInput
            placeholder="Reason for canceling the audit."
            style={{
              backgroundColor: '#eee',
              width: '100%',
              paddingHorizontal: 10,
              paddingBottom: 40,
            }}
            value={reason}
            onChangeText={text => setreason(text)}
          />
          <View style={{paddingHorizontal: 70}}>
            <Button buttonText={'Cancel'} onPress={onPress} />
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  primaryBtn: {
    paddingVertical: 12,
    marginBottom: 5,
  },
  primaryBtnText: {
    textAlign: 'center',
    fontFamily: FONT.PoppinsRegular,
    fontSize: SIZES.medium,
    lineHeight: 22,
    color: COLORS.white,
  },
  BlackBtnText:{
    textAlign: 'center',
    fontFamily: FONT.PoppinsRegular,
    fontSize: SIZES.font,
    lineHeight: 22,
    color: '#676767',    
  }
});
