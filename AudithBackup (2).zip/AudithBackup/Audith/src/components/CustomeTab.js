import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Appearance,
  ScrollView,
  Image,
} from 'react-native';
import {SvgXml} from 'react-native-svg';
import {COLORS, FONT, SIZES} from '../constants/themes';
import { SearchBar } from './CustomInput';
import Filter from '../../assets/images/Filter';

const CustomTabBar = ({navigationState, position, jumpTo}) => {

  const [search, setSearch] = useState('');
  // const [isTheme, setTheme] = useState('light');
  // useEffect(() => {
  //   const listener = Appearance.addChangeListener(colorTheme => {
  //     setTheme(colorTheme.colorScheme);
  //   });

  //   return () => {
  //     listener;
  //   };
  // }, []);
  return (
    <>
    <View
      style={{
        flexDirection: 'row',
        borderColor: COLORS.lightRed,
      }}>
      <ScrollView
        horizontal={true}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}>
        {navigationState.routes.map((route, index) => {
          const isFocused = navigationState.index === index;

          const onPress = () => {
            jumpTo(route.key);
          };

          return (
            <TouchableOpacity
              key={index}
              onPress={onPress}
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                // borderColor: COLORS.bordercolor,
                backgroundColor: isFocused ? COLORS.lightRed : COLORS.white,
                borderColor:
                  // ? COLORS.lightBlue
                  COLORS.bordercolor,
                borderRadius: 16,
                borderWidth: 1,
                marginHorizontal: 8,
                padding: 20,
              }}>
              <Image
                source={require('../../assets/images/complete.png')}
                style={{height: 32, width: 32, marginVertical: 8}}
              />
              <Text
                style={{
                  // color: isFocused
                  //   ? '#408BFB'
                  //   : isTheme === 'light'
                  //   ? '#408BFB'
                  //   : COLORS.DarkTheme.textColor,
                  fontFamily: FONT.PoppinsRegular,
                  fontSize: SIZES.font,
                  color: isFocused ? COLORS.primary : COLORS.textBlack,
                }}>
                {route.title}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>     
    </View>
    <View
        style={{
          marginVertical: 20,
          marginHorizontal: 20,
          flexDirection: 'row',
          // borderWidth:1 ,
        }}>
        <SearchBar
          placeholder={'Search for Bank Name'}
          value={search}
          setValue={setSearch}
        />
        <View
          style={{
            backgroundColor: COLORS.grayTextColor,
            padding: 10,
            borderRadius: 8,
          }}>
          <TouchableOpacity>
            <SvgXml xml={Filter} height={30} width={30} />
          </TouchableOpacity>
        </View>
      </View>
</>
  );
};

export default CustomTabBar;

const styles = StyleSheet.create({});
