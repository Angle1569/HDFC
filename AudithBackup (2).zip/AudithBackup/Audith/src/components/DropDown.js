import React, {useState} from 'react';
import {
  FlatList,
  Image,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {ARROW, COLORS, DOWNARROW, FONT} from '../constants/themes';
import {Input, SearchBar} from './CustomInput';

const DropDown = ({title, data, data_name, renderItem}) => {
  const [search, setsearch] = useState('');
  const [filterData, setfilterData] = useState(null);
  const [dropDown, setdropDown] = useState('');

  const handleDropDown = () => {
    setdropDown(!dropDown);
  };

  const handleSearch = text => {
    setsearch(text);
    const val = data.filter(city => {
      if (data_name === 'city_name')
        return city.city_name.toLowerCase().includes(search.toLowerCase());
      else return city.branch_name.toLowerCase().includes(search.toLowerCase());
    });
    setfilterData(val);
  };

  return (
    <>
      <TouchableOpacity onPress={() => handleDropDown()} style={styles.press}>
        <Text style={{fontFamily: FONT.PoppinsRegular, color: COLORS.black}}>
          {title}
        </Text>
        {dropDown ? (
          <Image
            source={DOWNARROW}
            style={{width: 12, height: 12,resizeMode:'contain', transform: [{rotateZ: '180deg'}]}}
          />
        ) : (
          <Image source={DOWNARROW} style={{width: 12, height: 12,resizeMode:'contain'}} />
        )}
      </TouchableOpacity>
      
    </>
  );
};

export default DropDown;

const styles = StyleSheet.create({
  press: {
    backgroundColor: COLORS.grayTextColor,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 5,
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 10,
    marginVertical: 10,
  },
});
