import React from 'react';
import {StyleSheet, View, TouchableOpacity, Image, Alert} from 'react-native';
import {ARROW, COLORS, Logo, Menu_Bar} from '../constants/themes';
import {SvgXml} from 'react-native-svg';
import AlertBell from '../../assets/images/AlertBell';
import ArrowBtn from '../../assets/images/ArrowBtn';
import Bell from '../../assets/images/Bell';

const Header = ({onPress}) => {
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={onPress}>
        <Image
          source={Logo}
          style={{
            width: 90,
            height: 50,
            resizeMode: 'contain',
            alignSelf: 'center',
          }}
        />
      </TouchableOpacity>
      <SvgXml xml={AlertBell} width={30} height={30} />
    </View>
  );
};

export default Header;

export const BackHeader = ({onPress}) => {
  return (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 10,
      }}>
      <TouchableOpacity
        style={{padding: 10, justifyContent: 'center'}}
        onPress={onPress}>
        <SvgXml xml={ArrowBtn} height={32} width={32} />
      </TouchableOpacity>
      <TouchableOpacity style={{padding: 10, justifyContent: 'center'}}>
        <SvgXml xml={Bell} height={32} width={32} />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flexDirection: 'row',
    backgroundColor: COLORS.white,
    justifyContent: 'space-between',
    height: Platform.OS == 'ios' ? 90 : 60,
    paddingTop: Platform.OS == 'ios' ? 30 : 0,
    marginHorizontal: 16,
    // borderWidth: 1
  },
});
