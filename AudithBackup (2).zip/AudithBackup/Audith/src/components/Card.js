import React, {useEffect, useState} from 'react';
import {View, Text, FlatList, ActivityIndicator} from 'react-native';
import {SvgXml} from 'react-native-svg';
import {COLORS, SHADOWS} from '../constants/themes';
import {styles} from '../../assets/css/MainStyles';
import Location from '../../assets/images/Location';
import Calendar from '../../assets/images/Calendar';
import Clock from '../../assets/images/Clock';
import {SecondaryBtn} from '../components/CustomButtom';
import {GET_BASE_URL, Token} from '../constants/api';

const Card = ({navigation}) => {
  const [auditList, setauditList] = useState([]);
  const [isLoading, setLoading] = useState(false);
  const [onRefresh, setOnRefresh] = useState(false);
  const [branchId, setBranchId] = useState('');
  const [data, setData] = useState([]);
  const [statusId, setStatusId] = useState();

  useEffect(() => {
    AuditList();
  }, [AuditList]);

  const AuditList = async () => {
    setLoading(true);
    try {
      var myHeaders = new Headers();
      myHeaders.append('Authorization', Token);

      var formdata = new FormData();
      formdata.append('page_no', '1');

      var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: formdata,
        redirect: 'follow',
      };

      const respond = await fetch(GET_BASE_URL + 'auditlist', requestOptions);
      const resJSON = await respond.json();
      console.log('list===>', resJSON.result);
      setData(resJSON.result);
      // setStatusId(resJSON.result[0].fldi_branch_id);
      // console.log('dtaa----', data);
      // console.log(resJSON.result[0].fldi_branch_id);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <View>
      {data.map(branchList => {
        return (
          <View
            style={{marginHorizontal: 20, marginBottom: 10}}
            key={branchList.fldi_id}>
            <View
              style={{
                width: '100%',
                height: 200,
                ...SHADOWS.light,
                borderTopLeftRadius: 8,
                borderTopRightRadius: 8,
                backgroundColor: COLORS.white,
              }}>
              <View
                style={{
                  padding: 16,
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <Text style={styles.redtext}>Bank Name</Text>
                <Text style={styles.textaudit}>Online Audit</Text>
              </View>
              <View
                style={{
                  height: 1,
                  backgroundColor: COLORS.grayTextColor,
                  marginHorizontal: 16,
                }}></View>
              <View>
                <View
                  style={{
                    //   marginVertical: 16,
                    marginTop: 16,
                    marginHorizontal: 16,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    //   borderWidth: 1,
                  }}>
                  <Text style={styles.txt_head}>Name Surname</Text>
                  <Text style={styles.text}>00 Members</Text>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginHorizontal: 16,
                    //   borderWidth: 1,
                  }}>
                  <Text style={styles.text}>Branch Manager Name</Text>
                  <Text style={styles.text}>Actionable Count</Text>
                </View>
              </View>

              <View
                style={{
                  height: 1,
                  backgroundColor: COLORS.grayTextColor,
                  marginHorizontal: 16,
                  marginTop: 16,
                }}></View>
              <View
                style={{
                  flexDirection: 'row',
                  marginHorizontal: 16,
                  marginVertical: 16,
                  gap: 5,
                }}>
                <SvgXml xml={Location} height={20} width={20} />
                <Text style={styles.text}>{branchList.branch_name} </Text>
                <SvgXml xml={Calendar} height={20} width={20} />
                <Text style={styles.text}>{branchList.fldd_audit_date} </Text>
                <SvgXml xml={Clock} height={20} width={20} />
                <Text style={styles.text}>{branchList.fldti_audit_time} </Text>
              </View>
            </View>
            <SecondaryBtn
              btnText={'Start Audit'}
              // onPress={() => navigation.navigate('QuestionScreen')}
            />
          </View>
        );
      })}
    </View>
  );
};

export default Card;

// <View style={{ marginHorizontal: 20, marginBottom: 10 }}>
//   <View
//     style={{
//       width: '100%',
//       height: 200,
//       ...SHADOWS.light,
//       borderTopLeftRadius: 8,
//       borderTopRightRadius: 8,
//       backgroundColor: COLORS.white,
//     }}>
//     <View
//       style={{
//         padding: 16,
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//       }}>
//       <Text style={styles.redtext}>Bank Name</Text>
//       <Text style={styles.textaudit}>Online Audit</Text>
//     </View>
//     <View
//       style={{
//         height: 1,
//         backgroundColor: COLORS.grayTextColor,
//         marginHorizontal: 16,
//       }}></View>
//     <View>
//       <View
//         style={{
//           //   marginVertical: 16,
//           marginTop: 16,
//           marginHorizontal: 16,
//           flexDirection: 'row',
//           justifyContent: 'space-between',
//           //   borderWidth: 1,
//         }}>
//         <Text style={styles.txt_head}>Name Surname</Text>
//         <Text style={styles.text}>00 Members</Text>
//       </View>
//       <View
//         style={{
//           flexDirection: 'row',
//           justifyContent: 'space-between',
//           marginHorizontal: 16,
//           //   borderWidth: 1,
//         }}>
//         <Text style={styles.text}>Branch Manager Name</Text>
//         <Text style={styles.text}>Actionable Count</Text>
//       </View>
//     </View>

//     <View
//       style={{
//         height: 1,
//         backgroundColor: COLORS.grayTextColor,
//         marginHorizontal: 16,
//         marginTop: 16,
//       }}></View>
//     <View
//       style={{
//         flexDirection: 'row',
//         marginHorizontal: 16,
//         marginVertical: 16,
//         gap: 5,
//       }}>
//       <SvgXml xml={Location} height={20} width={20} />
//       <Text style={styles.text}>Location </Text>
//       <SvgXml xml={Calendar} height={20} width={20} />
//       <Text style={styles.text}>00 Dec </Text>
//       <SvgXml xml={Clock} height={20} width={20} />
//       <Text style={styles.text}>Time </Text>
//     </View>
//   </View>
//   <SecondaryBtn btnText={'Start Audit'} />
// </View>
