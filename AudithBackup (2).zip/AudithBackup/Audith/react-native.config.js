module.exports = {
  assets: ['./assets'],
};
