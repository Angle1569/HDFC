export default `<svg width="335" height="284" viewBox="0 0 335 284" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0 24C0 10.7452 10.7452 0 24 0H311C324.255 0 335 10.7452 335 24V284H0V24Z" fill="url(#paint0_linear_9_13653)"/>
<defs>
<linearGradient id="paint0_linear_9_13653" x1="167.5" y1="0" x2="167.5" y2="284" gradientUnits="userSpaceOnUse">
<stop offset="0.585739" stop-color="white"/>
<stop offset="1" stop-color="#FDEECF"/>
</linearGradient>
</defs>
</svg>
`